package com.HeathHelper.entity;

public class CommentsEntity {
	private String commentsId;
	private String comments;
	private String date;
	private String userPhone;
	private String userName;
	private String userHead;
	private String postId;
	public String getCommentsId() {
		return commentsId;
	}
	public void setCommentsId(String commentsId) {
		this.commentsId = commentsId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date.substring(0,10);
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getPostId() {
		return postId;
	}
	public void setPostId(String postId) {
		this.postId = postId;
	}
	
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserHead() {
		return userHead;
	}
	public void setUserHead(String userHead) {
		this.userHead = userHead;
	}
	public String toString() {
		StringBuffer commentsInfo = new StringBuffer();
		commentsInfo.append("{");
		commentsInfo.append("commentsId:\"").append(commentsId).append("\",");
		commentsInfo.append("comments:\"").append(comments).append("\",");
		commentsInfo.append("date:\"").append(date).append("\",");
		commentsInfo.append("userPhone:\"").append(userPhone).append("\",");
		commentsInfo.append("userName:\"").append(userName).append("\",");
		commentsInfo.append("userHead:\"").append(userHead).append("\"");
		//commentsInfo.append("postId:\"").append(postId).append("\"");
		commentsInfo.append("},");
		return commentsInfo.toString();
	}

}
