package com.HeathHelper.entity;

/**
 * Created by TLE on 2015/11/13.
 */
public class LoginEntity {
    private String userPhone;
    private String userName;
    private String head;

    
    public String getUserPhone() {
		return userPhone;
	}


	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getHead() {
		return head;
	}


	public void setHead(String head) {
		this.head = head;
	}


	public String toString() {
    	StringBuffer info = new StringBuffer();
		info.append("{");
		info.append("userPhone:\"").append(userPhone).append("\",");
		info.append("userName:\"").append(userName).append("\",");
		info.append("head:\"").append(head).append("\"");
		info.append("}");
		return info.toString();
    	
    }
}
