package com.HeathHelper.entity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class PostInfoEntity {
	private String postId;
	private String userId;
	private String userName;
	private String userHead;
	private String postTitle;
	private String postBody;
	private String sendDate;
	private int countPraise;
	private int PostType;
	private String imgURL;

	public String getImgURL() {
		return imgURL;
	}

	public void setImgURL(String imgURL) {
		this.imgURL = imgURL;
	}

	private StringBuffer postInfo;

	public String getPostId() {
		return postId;
	}

	public void setPostId(String postId) {
		this.postId = postId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserHead() {
		return userHead;
	}

	public void setUserHead(String userHead) {
		this.userHead = userHead;
	}

	public String getPostTitle() {
		return postTitle;
	}

	public void setPostTitle(String postTitle) {
		this.postTitle = postTitle;
	}

	public String getPostBody() {
		return postBody;
	}

	public void setPostBody(String postBody) {
		this.postBody = postBody;
	}

	public String getSendDate() {
		return sendDate;
	}

	public void setSendDate(String sendDate) {
		this.sendDate = sendDate.substring(0, 10);
	}

	public int getCountPraise() {
		return countPraise;
	}

	public void setCountPraise(int countPraise) {

		this.countPraise = countPraise;
	}

	public int getPostType() {
		return PostType;
	}

	public void setPostType(int postType) {
		PostType = postType;
	}

	public String toString() {
		postInfo = new StringBuffer();
		postInfo.append("{");
		postInfo.append("postId:\"").append(postId).append("\",");
		postInfo.append("userId:\"").append(userId).append("\",");
		postInfo.append("userName:\"").append(userName).append("\",");
		postInfo.append("postTitle:\"").append(postTitle).append("\",");
		postInfo.append("userHead:\"").append(userHead).append("\",");
		System.out.println("����" + postTitle);
		postInfo.append("postBody:\"").append(postBody).append("\",");
		postInfo.append("sendDate:\"").append(sendDate).append("\",");
		postInfo.append("imgURL:\"").append(imgURL).append("\",");
		postInfo.append("countPraise:").append(countPraise).append(",");;
		postInfo.append("postType:").append(PostType);
		postInfo.append("},");
		return postInfo.toString();
	}

}
