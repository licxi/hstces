package com.HeathHelper.entity;

public class UserEntity {
	private String uphone; /* �û�ע���ֻ��� */
	private String uname; /* �û��� */
	private String upwd; /* ���� */
	private String uqq=null;
	private String uEmail=null; /* ���� */
	private String udis=null; /* ͷ��ID */
	private int uadmin=0;
	private String uhead;

	public String getUphone() {
		return uphone;
	}

	public void setUphone(String uphone) {
		this.uphone = uphone;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpwd() {
		return upwd;
	}

	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}

	public String getUqq() {
		return uqq;
	}

	public void setUqq(String uqq) {
		this.uqq = uqq;
	}

	public String getuEmail() {
		return uEmail;
	}

	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}

	public String getUdis() {
		return udis;
	}

	public void setUdis(String udis) {
		this.udis = udis;
	}

	public String getUhead() {
		return uhead;
	}

	public void setUhead(String uhead) {
		this.uhead = uhead;
	}

	public int getUadmin() {
		return uadmin;
	}

	public void setUadmin(int uadmin) {
		this.uadmin = uadmin;
	}

}
