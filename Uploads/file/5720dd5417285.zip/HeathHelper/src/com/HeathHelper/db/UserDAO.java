package com.HeathHelper.db;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.HeathHelper.entity.LoginEntity;


public class UserDAO {
	private MyConnection mCon;
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;

	public UserDAO() {
		mCon = new MyConnection();
	}

	/**
	 * �����û�
	 * 
	 * @param user
	 * @return ���� 1 �� 0 ��1�����ɹ���0����ʧ��
	 */
	/*public int insertUser(UserEntity user) {
		int count = 0;
		String sql = "insert into user(userPhone,userName,upwd,uqq,uEmail,udis,uadmin) values(?,?,?,?,?,?,?)";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, user.getuserPhone());
			ps.setString(2, user.getuserName());
			ps.setString(3, user.getUpwd());
			ps.setString(4, user.getUqq());
			ps.setString(5, user.getuEmail());
			ps.setString(6, user.getUdis());
			ps.setInt(7, user.getUadmin());
			count = ps.executeUpdate();
			if(count==1 && !user.getUhead().equals("")){
				insertUserHeadByuserPhone(user.getuserPhone(), user.getUhead());
			}
		} catch (SQLException e) {
			System.out.println("UserDAO.class:" + e.toString());
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return count;
	}*/
	
	/**
	 * �����û�
	 * @param userPhone �ֻ���
	 * @param userName �û���
	 * @param password ����
	 * @param uHead ͷ��
	 * @return 0 ע��ʧ�� 1ע��ɹ� 2�ֻ����Ѵ���
	 */
	public int insertUser(String userPhone, String userName, String password,
			String head) {
		if(queryUser(userPhone)){
			return 2;
		}
		String sql = "insert into user(userPhone,userName,password,head,isAdmin) values(?,?,?,?,0)";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, userPhone);
			ps.setString(2, userName);
			ps.setString(3, password);
			ps.setBinaryStream(4, new ByteArrayInputStream(head.getBytes()));
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("UserDAO.class:" + e.toString());
			return 0;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return 1;
	}
	/**
	 * ��ѯ�Ƿ�ID�Ƿ����
	 */
	public Boolean queryUser(String userPhone) {
		con = mCon.getConnection();
		String sql = "select * from user where userPhone = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, userPhone);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			} else
				return false;
		} catch (SQLException e) {
			System.out.println(e.toString());
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return false;
	}
	
	/**
	 * ���ID������
	 * 
	 * @param id
	 * @param passwork
	 * @return trueΪ��½�ɹ�  false ��½ʧ��
	 */
	public Boolean checkUserPhoneAndPassword(String userPhone, String password) {
		String sql = "select * from user where userPhone = ? and password=?";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, userPhone);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if(rs.next()){
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			System.out.println("��½����");
			return false;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
	}
	
	
	public LoginEntity getUserInfo(String userPhone) {
		LoginEntity le = null;
		String sql = "select userName,head from user where userPhone = ?";
		con = mCon.getConnection();
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, userPhone);
			rs = ps.executeQuery();
			if(rs.next()) {
				le = new LoginEntity();
				le.setUserPhone(userPhone);
				le.setUserName(rs.getString(1));
				le.setHead(inputStream2String(rs.getBinaryStream(2)));
				
			}
		} catch (SQLException e) {
			System.out.println("geiuserinfoerror"+e.toString());
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return le;
	}
	
	/**
	 * ȡ���û���
	 * @param userPhone
	 * @return
	 */
	public String getUserName(String userPhone) {
		String userName = null;
		String sql = "select userName from user where userPhone = ?";
		con = mCon.getConnection();
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, userPhone);
			rs = ps.executeQuery();
			if(rs.next()) {
				userName = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("geiuserinfoerror"+e.toString());
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return userName;
	}
	
	public String getUserHead(String userPhone) {
		String head = null;
		String sql = "select head from user where userPhone = ?";
		con = mCon.getConnection();
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, userPhone);
			rs = ps.executeQuery();
			if(rs.next()) {
				head = inputStream2String(rs.getBinaryStream(1));
				
			}
		} catch (SQLException e) {
			System.out.println("geiuserinfoerror"+e.toString());
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return head;
	}
	
	/**
	 * �����û�ͷ��
	 * @param uphone �û����ֻ��ţ����˺�
	 * @param headData �û�ͷ���String ����Ϊ BASE64
	 */
	public Boolean setUserHeadByuPhone(String userPhone,String head){
		String sql = "update user set head = ? where userPhone = ?";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setBinaryStream(1, new ByteArrayInputStream(head.getBytes()));
			ps.setString(2, userPhone);
			if(ps.executeUpdate()==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			System.out.println("add userHead error"+e.toString());
			return false;
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
	}
	
	public Boolean setUserNameByUserPhone(String userPhone, String updateName) {
		String sql = "update user set userName = ? where userPhone = ?";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, updateName);
			ps.setString(2, userPhone);
			if(ps.executeUpdate()==1){
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			System.out.println("add userName error"+e.toString());
			return false;
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
	}
	
	public String inputStream2String(InputStream is){
		String string = null;
		BufferedReader in = new BufferedReader(new InputStreamReader(is));
	    StringBuffer buffer = new StringBuffer();
	    try {
			while ((string = in.readLine()) != null){
			  buffer.append(string);
			}
		} catch (IOException e) {
			System.out.println("inputStream2StringError:"+e.toString());
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				System.out.println(e.toString());
			}
		}
	    return buffer.toString();
	}


}
