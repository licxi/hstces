package com.HeathHelper.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.HeathHelper.entity.GoodsEntity;




public class GoodsDAO {
	private MyConnection mCon;
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	private ArrayList<GoodsEntity> resultList;
	private GoodsEntity goods;

	public GoodsDAO() {
		mCon = new MyConnection();
	}
	/**
	 * ��ѯ������Ʒ
	 * @return ��Ʒ�б�
	 */
	public ArrayList<GoodsEntity> query(){
		String sql = "select * from goods";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			resultList = new ArrayList<GoodsEntity>();
			while (rs.next()) {
				goods = new GoodsEntity();
				goods.setGoodsId(rs.getString(1));
				goods.setGoodsName(rs.getString(2));
				goods.setGoodsImgURI(rs.getString(3));
				goods.setGoodsNumber(rs.getInt(4));
				goods.setPrice(rs.getDouble(5));
				goods.setMerchantId(rs.getString(6));
				resultList.add(goods);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return resultList;
	}
	
	/**
	 * ��ѯ��Ʒ����
	 * @param goodsId
	 * @return
	 */
	public GoodsEntity queryByGoodsId(String goodsId){
		String sql = "select * from goods where goodId = ?";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, goodsId);
			rs = ps.executeQuery();
			while (rs.next()) {
				goods = new GoodsEntity();
				goods.setGoodsId(rs.getString(1));
				goods.setGoodsName(rs.getString(2));
				goods.setGoodsImgURI(rs.getString(3));
				goods.setGoodsNumber(rs.getInt(4));
				goods.setPrice(rs.getDouble(5));
				goods.setMerchantId(rs.getString(6));
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return goods;
	} 
	
	/**
	 * ���ӹ��ﳵ�����ﳵɾ����ƷʱҪ�޸���Ӧ����Ʒ������
	 * @param goodsId
	 * @param number
	 * @return
	 */
	public boolean modifyNumber(String goodsId, int number) {
		String sql = "update goods set goodNumber = goodNumber+? where goodId = ?";
		con = mCon.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, number);
			ps.setString(2, goodsId);
			if(ps.executeUpdate()>0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return false;
	}

}
