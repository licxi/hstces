package com.HeathHelper.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
	
	final static String NAME = "com.mysql.jdbc.Driver";
	final static String RUL = "jdbc:mysql://localhost/heath_helper";
	final static String USER = "root";
	final static String PASSWORD = "417708459";
	private Connection con;
	
	/**
	 * ��ȡ���ݿ�����
	 * @return Connection
	 */
	public Connection getConnection(){
		try {
			Class.forName(NAME);
		} catch (ClassNotFoundException e) {
			System.out.println("DriverError");
		}
		try {
			con = DriverManager.getConnection(RUL+"?user="+USER+"&password="+PASSWORD);
			System.out.println("���ӳɹ�");
		} catch (SQLException e) {
			System.out.println("error"+e.toString());
		}
		return con;
	}
	
	/**
	 * �ر�����
	 * @param con
	 */
	public void closeConnecton(Connection con){
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("closeError");
			}
		}
	}
	
}
