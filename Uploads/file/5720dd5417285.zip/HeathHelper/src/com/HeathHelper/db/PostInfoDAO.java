package com.HeathHelper.db;


import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.HeathHelper.entity.PostInfoEntity;


public class PostInfoDAO {
	private MyConnection mCon;
	private PreparedStatement pStatement;
	private Connection con;
	private ResultSet rs;
	private PostInfoEntity postInfo;
	private ArrayList<PostInfoEntity> resultList;
	private Date date;
	private SimpleDateFormat dateFormat;
	private String nowDate;
	private String userId;
	private UserDAO userInfo;
	
	
	public PostInfoDAO(){
		mCon = new MyConnection();
	}
	
	/**
	 * ��������
	 * @param post
	 * @return 1���ӳɹ��� 0����ʧ��
	 */
	public int  addpost(PostInfoEntity post){
		String sql ="insert into posts(postTitle,postBody,sendDate,countPraise,postType,userPhone) values(?,?,now(),?,?,?)";
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			pStatement.setString(1, post.getPostTitle());
			pStatement.setString(2, post.getPostBody());
			pStatement.setInt(3, 0);
			pStatement.setInt(4,post.getPostType());
			pStatement.setString(5, post.getUserId());
			if(pStatement.executeUpdate() == 1){
				return 1;
			}
			else
				return 0;
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}
		return 0;
	}
	
	
	/**
	 * ��ȡ�����б�
	 * @param psotType
	 * @return
	 */
	public ArrayList<PostInfoEntity> getpost(int postType){
		String sql = "select postId,postTitle,postBody,sendDate,countPraise,userPhone,imgURL from posts where postType= ?";
		resultList = new ArrayList<PostInfoEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			pStatement.setInt(1, postType);
			rs = pStatement.executeQuery();
			while(rs.next()){
				postInfo = new PostInfoEntity();
				postInfo.setPostId(rs.getString(1));
				postInfo.setPostTitle(rs.getString(2));
				postInfo.setPostBody(rs.getString(3));
				postInfo.setSendDate(rs.getString(4));
				postInfo.setCountPraise(rs.getInt(5));
				userId = rs.getString(6);
				postInfo.setUserId(userId);
				postInfo.setUserName(userInfo.getUserName(userId));
				postInfo.setUserHead(userInfo.getUserHead(userId));
				postInfo.setImgURL(rs.getString(7));
				resultList.add(postInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}
		return resultList;
	}
	
	public ArrayList<PostInfoEntity> getStudyPost(){
		String sql = "select postId,postTitle,postBody,sendDate,countPraise,postType,userPhone,imgURL from posts where postType != 3";
		resultList = new ArrayList<PostInfoEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			rs = pStatement.executeQuery();
			while(rs.next()){
				postInfo = new PostInfoEntity();
				postInfo.setPostId(rs.getString(1));
				postInfo.setPostTitle(rs.getString(2));
				postInfo.setPostBody(rs.getString(3));
				postInfo.setSendDate(rs.getString(4));
				postInfo.setCountPraise(rs.getInt(5));
				postInfo.setPostType(rs.getInt(6));
				userId = rs.getString(7);
				postInfo.setUserId(userId);
				postInfo.setUserName(userInfo.getUserName(userId));
				postInfo.setUserHead(userInfo.getUserHead(userId));
				postInfo.setImgURL(rs.getString(8));
				resultList.add(postInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}
		return resultList;
	}
	
	
	public ArrayList<PostInfoEntity> getpost(){
		String sql = "select postId,postTitle,postBody,sendDate,countPraise,userPhone from posts";
		resultList = new ArrayList<PostInfoEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			rs = pStatement.executeQuery();
			while(rs.next()){
				postInfo = new PostInfoEntity();
				postInfo.setPostId(rs.getString(1));
				postInfo.setPostTitle(rs.getString(2));
				postInfo.setPostBody(rs.getString(3));
				postInfo.setSendDate(rs.getString(4));
				postInfo.setCountPraise(rs.getInt(5));
				userId = rs.getString(6);
				postInfo.setUserId(userId);
				postInfo.setUserName(userInfo.getUserName(userId));
				postInfo.setUserHead(userInfo.getUserHead(userId));
				postInfo.setImgURL(rs.getString(7));
				resultList.add(postInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}
		return resultList;
	}
}
