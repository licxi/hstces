package com.HeathHelper.db;


import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.HeathHelper.entity.CommentsEntity;
import com.HeathHelper.entity.PostInfoEntity;


public class CommentsDAO {
	private MyConnection mCon;
	private PreparedStatement pStatement;
	private Connection con;
	private ResultSet rs;
	private CommentsEntity commentsInfo;
	private ArrayList<CommentsEntity> resultList;
	private Date date;
	private SimpleDateFormat dateFormat;
	private String nowDate;
	private String userPhone;
	private UserDAO userInfo;
	
	
	public CommentsDAO(){
		mCon = new MyConnection();
	}
	
	/**
	 * ������������
	 * @param post
	 * @return 1���ӳɹ��� 0����ʧ��
	 */
	public int  addpost(CommentsEntity comments){
		String sql ="insert into comments(comments,date,userPhone,postId) values(?,now(),?,?)";
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			pStatement.setString(1, comments.getComments());
			pStatement.setString(2, comments.getUserPhone());
			pStatement.setString(3,comments.getPostId());
			if(pStatement.executeUpdate() == 1){
				return 1;
			}
			else
				return 0;
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}  finally{
			try {
				if (pStatement != null) {
					pStatement.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return 0;
	}
	
	
	/**
	 * ��ȡ���������б�
	 * @param psotType
	 * @return
	 */
	public ArrayList<CommentsEntity> getpost(String postId){
		String sql = "select commentsId,comments,date,userPhone from comments where postId= ?";
		resultList = new ArrayList<CommentsEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			pStatement.setString(1, postId);
			rs = pStatement.executeQuery();
			while(rs.next()){
				commentsInfo = new CommentsEntity();
				commentsInfo.setCommentsId(rs.getString(1));
				commentsInfo.setComments(rs.getString(2));
				commentsInfo.setDate(rs.getString(3));
				userPhone = rs.getString(4);
				commentsInfo.setUserPhone(userPhone);
				commentsInfo.setUserName(userInfo.getUserName(userPhone));
				commentsInfo.setUserHead(userInfo.getUserHead(userPhone));
				resultList.add(commentsInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		} finally{
			try {
				if (pStatement != null) {
					pStatement.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return resultList;
	}
	
	/*public ArrayList<CommentsEntity> getStudyPost(){
		String sql = "select postId,postTitle,postBody,sendDate,countPraise,postType,userPhone,imgURL from posts where postType != 3";
		resultList = new ArrayList<CommentsEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			rs = pStatement.executeQuery();
			while(rs.next()){
				commentsInfo = new CommentsEntity();
				commentsInfo = new CommentsEntity();
				commentsInfo.setCommentsId(rs.getString(1));
				commentsInfo.setComments(rs.getString(2));
				commentsInfo.setDate(rs.getString(3));
				userPhone = rs.getString(6);
				commentsInfo.setUserPhone(userPhone);
				commentsInfo.setUserName(userInfo.getUserName(userPhone));
				commentsInfo.setUserHead(userInfo.getUserHead(userPhone));
				resultList.add(commentsInfo);
				resultList.add(commentsInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		}
		return resultList;
	}*/
	
	/**
	 * ��ȡȫ������
	 * @return
	 */
	public ArrayList<CommentsEntity> getpost(){
		String sql = "select postId,postTitle,postBody,sendDate,countPraise,userPhone from posts";
		resultList = new ArrayList<CommentsEntity>();
		userInfo = new UserDAO();
		con = mCon.getConnection();
		try {
			pStatement = con.prepareStatement(sql);
			rs = pStatement.executeQuery();
			while(rs.next()){
				commentsInfo = new CommentsEntity();
				commentsInfo.setCommentsId(rs.getString(1));
				commentsInfo.setComments(rs.getString(2));
				commentsInfo.setDate(rs.getString(3));
				userPhone = rs.getString(6);
				commentsInfo.setUserPhone(userPhone);
				commentsInfo.setUserName(userInfo.getUserName(userPhone));
				commentsInfo.setUserHead(userInfo.getUserHead(userPhone));
				resultList.add(commentsInfo);
			}
			
		} catch (SQLException e) {
			System.out.println("PostInfoDAO:"+e.toString());
		} finally{
			try {
				if (pStatement != null) {
					pStatement.close();
				}
			} catch (SQLException e) {
				System.out.println("CLOSE_PS_ERROR"+e.toString());
			}
			mCon.closeConnecton(con);
		}
		return resultList;
	}
}
