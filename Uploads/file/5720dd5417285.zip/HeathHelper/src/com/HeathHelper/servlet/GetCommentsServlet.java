package com.HeathHelper.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.HeathHelper.db.CommentsDAO;
import com.HeathHelper.db.PostInfoDAO;
import com.HeathHelper.entity.CommentsEntity;
import com.HeathHelper.entity.PostInfoEntity;


public class GetCommentsServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String postId;
	private StringBuffer json;
	private CommentsDAO comments;
	private ArrayList<CommentsEntity> resultList;
	private int length;
	
	public GetCommentsServlet() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			postId = request.getParameter("postId");
			System.out.println("����"+postId);
			comments = new CommentsDAO();
			json = new StringBuffer();
			resultList = comments.getpost(postId);
			json.append("[");
			/*for(PostInfoModel post : resultList){
				json.append(post.toString());
			}*/
			
			length = resultList.size();
			for(int i = length-1;i>=0;i--){
				json.append(resultList.get(i).toString());
			}
			if (json.length() != 1) {
				json.deleteCharAt(json.length() - 1);
			}
			json.append("]");
			System.out.println(json.toString());
			request.setAttribute("json", json.toString());
			request.getRequestDispatcher("GetComments.jsp").forward(
					request, response);
	}
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
