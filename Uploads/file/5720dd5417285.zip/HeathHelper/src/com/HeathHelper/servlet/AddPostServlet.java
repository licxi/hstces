package com.HeathHelper.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.HeathHelper.db.PostInfoDAO;
import com.HeathHelper.entity.PostInfoEntity;

public class AddPostServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PostInfoDAO postInfo;
	private PostInfoEntity post;
	private int status=0;
	/**
	 * Constructor of the object.
	 */
	public AddPostServlet() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		PrintWriter out = response.getWriter();
		postInfo = new PostInfoDAO();
		post = new PostInfoEntity();
		request.setCharacterEncoding("utf-8");
		post.setUserId(request.getParameter("userId"));
		String postTitle = request.getParameter("postTitle");
		//postTitle = new String(postTitle.getBytes("ISO8859-1"),"UTF-8");
		post.setPostTitle(postTitle);
		String postBody = request.getParameter("postBody");
		//postBody = new String(postBody.getBytes("ISO8859-1"),"UTF-8");
		post.setPostBody(postBody);
		System.out.println("����"+postTitle);
		System.out.println("����"+postBody);
		post.setPostType(Integer.parseInt(request.getParameter("postType")));
		status = postInfo.addpost(post);
	/*	request.setAttribute("status", status);
		request.getRequestDispatcher("WEB-INF/page/AddPost.jsp").forward(
				request, response);*/
		out.print(status+"");

		out.flush();
		out.close();
	}

}
