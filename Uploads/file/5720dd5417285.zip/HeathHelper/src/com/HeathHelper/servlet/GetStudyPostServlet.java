package com.HeathHelper.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.HeathHelper.db.PostInfoDAO;
import com.HeathHelper.entity.PostInfoEntity;


public class GetStudyPostServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private StringBuffer json;
	private PostInfoDAO postInfo;
	private ArrayList<PostInfoEntity> resultList;
	private int length;
	
	public GetStudyPostServlet() {
		super();
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			postInfo = new PostInfoDAO();
			resultList = new ArrayList<PostInfoEntity>();
			json = new StringBuffer();
			resultList = postInfo.getStudyPost();
			json.append("[");
			length = resultList.size();
			for(int i = length-1;i>=0;i--){
				json.append(resultList.get(i).toString());
			}
			if (json.length() != 1) {
				json.deleteCharAt(json.length() - 1);
			}
			json.append("]");
			request.setAttribute("json", json.toString());
			request.getRequestDispatcher("WEB-INF/page/GetPost.jsp").forward(
					request, response);
	}
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
