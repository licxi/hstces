package com.HeathHelper.service;

import java.util.ArrayList;

import com.HeathHelper.entity.CommentsEntity;

public interface CommentsService {
	public abstract int addComments(CommentsEntity comments);
	public abstract ArrayList<CommentsEntity> queryCommentsByPostId(String postId);

}
