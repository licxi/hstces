package com.HeathHelper.service;

import java.util.ArrayList;

import com.HeathHelper.entity.GoodsEntity;


public interface GoodsService {
	public abstract ArrayList<GoodsEntity> query();
	public abstract GoodsEntity queryByGoodsId(String goodsId);
}
