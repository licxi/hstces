package com.HeathHelper.servicebean;

import java.util.ArrayList;

import com.HeathHelper.db.GoodsDAO;
import com.HeathHelper.entity.GoodsEntity;
import com.HeathHelper.service.GoodsService;



public class GoodsServiceBean implements GoodsService {
	private ArrayList<GoodsEntity> resultList;
	private GoodsEntity goods;
	private GoodsDAO goodsDAO;

	/**
	 * ��ѯ���е���Ʒ
	 */
	@Override
	public ArrayList<GoodsEntity> query() {
		goodsDAO = new GoodsDAO();
		resultList = goodsDAO.query();
		return resultList;
	}

	/**
	 * ���ز�ѯ����Ʒ����ϸ��Ϣ
	 * 
	 */
	@Override
	public GoodsEntity queryByGoodsId(String goodsId) {
		goodsDAO = new GoodsDAO();
		goods = goodsDAO.queryByGoodsId(goodsId);
		return goods;
	}

}
