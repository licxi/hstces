package com.HeathHelper.servicebean;

import java.util.ArrayList;

import com.HeathHelper.db.CommentsDAO;
import com.HeathHelper.entity.CommentsEntity;
import com.HeathHelper.service.CommentsService;

public class CommentsServiceBean implements CommentsService {
	private CommentsDAO commmentsDAO;
	private ArrayList<CommentsEntity> CommentsList;

	@Override
	public int addComments(CommentsEntity comments) {
		int count = 0;
		commmentsDAO = new CommentsDAO();
		count = commmentsDAO.addpost(comments);
		return count;
	}

	@Override
	public ArrayList<CommentsEntity> queryCommentsByPostId(String postId) {
		commmentsDAO = new CommentsDAO();
		CommentsList = commmentsDAO.getpost(postId);
		return CommentsList;
	}

}
