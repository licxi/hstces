package com.HeathHelper.servicebean;

import com.HeathHelper.db.UserDAO;
import com.HeathHelper.entity.LoginEntity;
import com.HeathHelper.service.UserInfoService;

public class UserInfoServiceBean implements UserInfoService {
	private UserDAO userDAO;
	private LoginEntity le;
	
	//�����û���ͷ��
	/**
	 * 
	 */
	@Override
	public Boolean setUserHeadByUserPhone(String userPhone, String head) {
		userDAO = new UserDAO();
		return userDAO.setUserHeadByuPhone(userPhone, head);
	}
	//�û���¼������֤�ɹ�ʱ�������û����ֻ��ţ��û�����ͷ����Ϣ
	@Override
	public String userLogin(String userPhone, String password) {
		StringBuffer loginInfo  = new StringBuffer();
		userDAO = new UserDAO();
		if(userDAO.checkUserPhoneAndPassword(userPhone, password)) {
			loginInfo.append("1");
			le = userDAO.getUserInfo(userPhone);
			if(le!=null){
				loginInfo.append(le.toString());
			}
		} else {
			loginInfo.append("0");
		}
		return loginInfo.toString();
	}
	//�޸�����
	@Override
	public boolean modifyPassword(String userPhone, String userOldPassword,
			String userNewPassword) {
		return false;
	}
	//�û�ע��
	@Override
	public int register(String userPhone, String userName, String password,
			String head) {
		int status;
		userDAO = new UserDAO();
		status = userDAO.insertUser(userPhone, userName, password, head);
		return status;
	}
	@Override
	public String getUserHeadByUserPhone(String userPhone) {
		
		return null;
	}
	/**
	 * �޸��û���
	 */
	@Override
	public Boolean setUserNameByUserPhone(String updateName, String userPhone) {
		userDAO = new UserDAO();
		return userDAO.setUserNameByUserPhone(userPhone, updateName);
	}

}
