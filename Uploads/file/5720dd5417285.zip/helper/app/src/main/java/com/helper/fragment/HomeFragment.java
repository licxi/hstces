package com.helper.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.MyHomeGridViewAdapter;
import com.helper.adapter.MyHomeListViewAdapter;
import com.helper.adapter.MyViewPagerAdapter;
import com.helper.entity.PostInfoEntity;
import com.helper.ui.DisallowParentTouchViewPager;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.apache.http.Header;

import java.lang.reflect.Type;
import java.util.ArrayList;

import in.srain.cube.views.ptr.PtrClassicFrameLayout;
import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;
import in.srain.cube.views.ptr.PtrHandler;
import in.srain.cube.views.ptr.header.MaterialHeader;
import in.srain.cube.views.ptr.util.PtrLocalDisplay;


/**
 * 主页
 * Created by 岑溪 on 2015/8/12.
 */
public class HomeFragment extends Fragment implements AdapterView.OnItemClickListener {
    private View view;
    private View getViewPager;
    private ListView lv_homeShow;
    private PtrClassicFrameLayout mPtrFrameLayout;
    private MyViewPagerAdapter viewPagerAdapter;
    private MyHomeListViewAdapter listViewAdapter;
    private ImageView[] imageViews;
    private int[] imgId;
    private int[] typeImgId;
    private MaterialHeader header;
    private ImageView image;
    private DisallowParentTouchViewPager vp_home_show;
    private LayoutInflater inflater;
    private ViewGroup container;
    private int[] colors;
    private GridView gv_mTypeImg;
    private View getGridView;
    private MyHomeGridViewAdapter myHomeGridViewAdapter;
    private AsyncHttpClient client;


    private ArrayList<PostInfoEntity> data;
    public boolean load;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.inflater = inflater;
        this.container = container;
        view = inflater.inflate(R.layout.fragment_home, container, false);


        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        assignViews();
        imgId = new int[]{R.drawable.one, R.drawable.two, R.drawable.there, R.drawable.four, R.drawable.five};
        typeImgId = new int[]{R.drawable.btn_1, R.drawable.btn_2, R.drawable.btn_6, R.drawable.btn_7, R.drawable.btn_5,
                R.drawable.btn_4, R.drawable.btn_3, R.drawable.btn_8};
        imageViews = new ImageView[imgId.length];
        for (int i = 0; i < imageViews.length; i++) {
            image = new ImageView(view.getContext());
            imageViews[i] = image;
            image.setBackgroundResource(imgId[i]);
        }
        viewPagerAdapter = new MyViewPagerAdapter(imageViews);
        myHomeGridViewAdapter = new MyHomeGridViewAdapter(typeImgId, view.getContext());

        vp_home_show.setAdapter(viewPagerAdapter);
        gv_mTypeImg.setAdapter(myHomeGridViewAdapter);
        getData();
        mPtrFrameLayout.disableWhenHorizontalMove(true);
        mPtrFrameLayout.setHorizontalScrollBarEnabled(true);
        mPtrFrameLayout.setResistance(1.2f);
        mPtrFrameLayout.setPtrHandler(new PtrHandler() {
            @Override
            public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
                return PtrDefaultHandler.checkContentCanBePulledDown(frame, lv_homeShow, header);

            }

            @Override
            public void onRefreshBegin(final PtrFrameLayout frame) {
                getMoreData();
                // show();
                frame.refreshComplete();
            }
        });
        setListener();


    }

    private void setListener() {
        gv_mTypeImg.setOnItemClickListener(this);
    }

    private void init() {

        // getViewPager = inflater.inflate(R.layout.home_viewpager, container, false);
        getViewPager = View.inflate(inflater.getContext(), R.layout.home_viewpager, null);
        vp_home_show = (DisallowParentTouchViewPager) getViewPager.findViewById(R.id.vp_home_show);
        lv_homeShow.addHeaderView(getViewPager);

        imgId = new int[]{R.drawable.one, R.drawable.two, R.drawable.there, R.drawable.four, R.drawable.five};
        imageViews = new ImageView[imgId.length];
        for (int i = 0; i < imageViews.length; i++) {
            image = new ImageView(view.getContext());
            imageViews[i] = image;
            image.setBackgroundResource(imgId[i]);
        }
        viewPagerAdapter = new MyViewPagerAdapter(imageViews);
        vp_home_show.setAdapter(viewPagerAdapter);

        header = new MaterialHeader(view.getContext());
        colors = getResources().getIntArray(R.array.google_colors);
        header.setColorSchemeColors(colors);
        header.setLayoutParams(new PtrClassicFrameLayout.LayoutParams(-1, -2));
        header.setPadding(0, PtrLocalDisplay.dp2px(15), 0, PtrLocalDisplay.dp2px(10));
        mPtrFrameLayout.setLoadingMinTime(1000);
        mPtrFrameLayout.setDurationToCloseHeader(1500);
        mPtrFrameLayout.setHeaderView(header);
        mPtrFrameLayout.addPtrUIHandler(header);
        mPtrFrameLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                mPtrFrameLayout.autoRefresh(false);
            }
        }, 100);
        mPtrFrameLayout.setPtrHandler(new PtrHandler() {
            @Override
            public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
                /*if(listViewAdapter.getCount() == 0 || lv_homeShow == null) {
                    return true;
                }
               // Log.e("test", "checkCanDoRefresh: %s %s", lv_homeShow.getFirstVisiblePosition(), lv_homeShow.getChildAt(0).getTop());
                Log.e("PO:"+lv_homeShow.getFirstVisiblePosition(),"GETTOP:"+lv_homeShow.getChildAt(0).getTop()+"");
               return lv_homeShow.getFirstVisiblePosition()==0 && lv_homeShow.getChildAt(0).getTop()==0;
               //return vp_home_show.getVisibility() == View.INVISIBLE;
                //return  lv_homeShow.areHeaderDividersEnabled();*/
                // return PtrDefaultHandler.checkContentCanBePulledDown(frame, lv_homeShow, header);
                //return lv_homeShow.getFirstVisiblePosition() == 0 && lv_homeShow.getChildAt(0).getTop() == 0;
                return false;
            }

            @Override
            public void onRefreshBegin(final PtrFrameLayout frame) {

                getMoreData();
                show();
                frame.refreshComplete();
            }
        });
        getData();
        show();


    }


    public void getData() {
        String url = "http://" + MyApplication.IP + "/HeathHelper/GetStudyPostServlet";
        client = new AsyncHttpClient();
        client.post(url, null, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Gson gson = new Gson();
                Type list = new TypeToken<ArrayList<PostInfoEntity>>() {
                }.getType();
                data = gson.fromJson(response, list);
                show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                Toast.makeText(view.getContext(), "加载失败！", Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void getMoreData() {

        load = false;
        // Toast.makeText(this, data.get(2).toString(), Toast.LENGTH_SHORT).show();
        getData();
    }

    public void show() {
        if (listViewAdapter == null) {
            lv_homeShow = (ListView) view.findViewById(R.id.lv_home_show);
            listViewAdapter = new MyHomeListViewAdapter(data, view.getContext());
            lv_homeShow.setAdapter(listViewAdapter);
        } else {
            // listViewAdapter.onDataChanged(data);
            lv_homeShow.setAdapter(listViewAdapter);
        }
    }


    public void assignViews() {
        mPtrFrameLayout = (PtrClassicFrameLayout) view.findViewById(R.id.fl_classic_style);
        lv_homeShow = (ListView) view.findViewById(R.id.lv_home_show);
        // getViewPager = inflater.inflate(R.layout.home_viewpager, container, false);
        getViewPager = View.inflate(inflater.getContext(), R.layout.home_viewpager, null);
        getGridView = View.inflate(inflater.getContext(), R.layout.home_gridview, null);
        vp_home_show = (DisallowParentTouchViewPager) getViewPager.findViewById(R.id.vp_home_show);
        gv_mTypeImg = (GridView) getGridView.findViewById(R.id.gv_type_img);
        lv_homeShow.addHeaderView(getViewPager);
        lv_homeShow.addHeaderView(getGridView);

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent type = new Intent(view.getContext(), com.helper.ui.Type.class);
        if(position == 2) {
            type.putExtra("typeId",4);
            type.putExtra("type", "中医常识");
            startActivity(type);
        }
        if(position == 3 ) {
            type.putExtra("typeId",1);
            type.putExtra("type", "美容");
            startActivity(type);
        }

    }
}
