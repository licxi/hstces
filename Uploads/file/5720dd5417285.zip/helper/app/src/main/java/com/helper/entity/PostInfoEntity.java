package com.helper.entity;

public class PostInfoEntity {
    private String postId;
    private String userId;
    private String userName;
    private String userHead;
    private String postTitle;
    private String postBody;
    private String sendDate;
    private String imgURL;
    private int countPraise;
    private int postType;

    private StringBuffer postInfo;

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserHead() {
        return userHead;
    }

    public void setUserHead(String userHead) {
        this.userHead = userHead;
    }

    public String getPostTitle() {
        return postTitle;
    }

    public void setPostTitle(String postTitle) {
        this.postTitle = postTitle;
    }

    public String getPostBody() {
        return postBody;
    }

    public void setPostBody(String postBody) {
        this.postBody = postBody;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate.substring(0, 14);
    }

    public int getCountPraise() {
        return countPraise;
    }

    public void setCountPraise(int countPraise) {

        this.countPraise = countPraise;
    }

    public int getPostType() {
        return postType;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String toString() {
        postInfo = new StringBuffer();
        postInfo.append("{");
        postInfo.append("postId:\"").append(postId).append("\",");
        postInfo.append("userId:\"").append(userId).append("\",");
        postInfo.append("userName:\"").append(userName).append("\",");
        postInfo.append("userHead:\"").append(userHead).append("\",");
        postInfo.append("postTitle:\"").append(postTitle).append("\",");
        postInfo.append("postBody:\"").append(postBody).append("\",");
        postInfo.append("sendDate:\"").append(sendDate).append("\",");
        postInfo.append("countPraise:").append(countPraise);
        postInfo.append("},");
        return postInfo.toString();
    }

}
