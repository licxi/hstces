package com.helper.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.LeftMenuAdapter;
import com.helper.fragment.HeathChatFragment;
import com.helper.fragment.HomeFragment;
import com.helper.fragment.HeathStudyFragment;
import com.helper.fragment.HeathTradeFragment;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

public class MainActivity extends FragmentActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private ImageButton ib_head;
    private ImageView iv_headOnLeft;
    private TextView tv_userName;
    private ImageLoader loader = ImageLoader.getInstance();

    private RelativeLayout rl_userInfo;
    private SlidingMenu mMenu;
    private LinearLayout rightContent;
    private HomeFragment homeFragment;
    private HeathStudyFragment heathStudyFragment;
    private HeathTradeFragment heathTradeFragment;
    private HeathChatFragment heathChatFragment;


    private TextView tv_home;
    private TextView tv_heath_study;
    private TextView tv_heath_trade;
    private TextView tv_heath_chat;

    private ListView lv_left_menu;
    private String[] leftMenuTip;
    private ArrayList<String> list;
    private LeftMenuAdapter adapter;

    private ImageButton ib_writePost;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        assignViews();
        setLeftMenu();
        select(0);
        setHead();
        setListener();
    }

    private void setLeftMenu() {
        leftMenuTip = getResources().getStringArray(R.array.sa_left_menu_tip);
        list = new ArrayList<>();
        for (String s : leftMenuTip) {
            list.add(s);
        }
        adapter = new LeftMenuAdapter(list, getApplicationContext());
        lv_left_menu.setAdapter(adapter);

    }

    public void select(int i) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction(); //创建事务
        hideFragment(transaction);
        changeColor();
        switch (i) {
            case 0:
                if (homeFragment == null) {
                    homeFragment = new HomeFragment();
                    transaction.add(R.id.id_content, homeFragment);
                } else {
                    transaction.show(homeFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_home.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 1:
                if (heathStudyFragment == null) {
                    heathStudyFragment = new HeathStudyFragment();
                    transaction.add(R.id.id_content, heathStudyFragment);
                } else {
                    transaction.show(heathStudyFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_heath_study.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 2:
                if (heathTradeFragment == null) {
                    heathTradeFragment = new HeathTradeFragment();
                    transaction.add(R.id.id_content, heathTradeFragment);
                } else {
                    transaction.show(heathTradeFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_heath_trade.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 3:
                if (heathChatFragment == null) {
                    heathChatFragment = new HeathChatFragment();
                    transaction.add(R.id.id_content, heathChatFragment);
                } else {
                    transaction.show(heathChatFragment);
                }
                ib_writePost.setVisibility(View.VISIBLE);
                tv_heath_chat.setTextColor(getResources().getColor(R.color.blue));
                break;
        }
        transaction.commit();
    }

    /**
     * 隐藏所有的Fragment
     *
     * @param transaction
     */
    private void hideFragment(FragmentTransaction transaction) {
        if (homeFragment != null) {
            transaction.hide(homeFragment);
        }
        if (heathStudyFragment != null) {
            transaction.hide(heathStudyFragment);
        }
        if (heathTradeFragment != null) {
            transaction.hide(heathTradeFragment);
        }
        if (heathChatFragment != null) {
            transaction.hide(heathChatFragment);
        }

    }

    private void setListener() {
        ib_head.setOnClickListener(this);
        tv_home.setOnClickListener(this);
        tv_heath_study.setOnClickListener(this);
        tv_heath_trade.setOnClickListener(this);
        tv_heath_chat.setOnClickListener(this);
        // rightContent.setOnClickListener(this);
        rl_userInfo.setOnClickListener(this);
        lv_left_menu.setOnItemClickListener(this);
        ib_writePost.setOnClickListener(this);
    }

    private void assignViews() {
        ib_head = (ImageButton) findViewById(R.id.ib_head);
        rightContent = (LinearLayout) findViewById(R.id.right_content);
        tv_home = (TextView) findViewById(R.id.tv_home);
        tv_heath_study = (TextView) findViewById(R.id.tv_heath_study);
        tv_heath_trade = (TextView) findViewById(R.id.tv_heath_trade);
        tv_heath_chat = (TextView) findViewById(R.id.tv_heath_chat);
        mMenu = (SlidingMenu) findViewById(R.id.left_menu);
        mMenu.setHeadAnimation(ib_head);
        iv_headOnLeft = (ImageView) findViewById(R.id.iv_head_left);
        tv_userName = (TextView) findViewById(R.id.tv_user_name);
        rl_userInfo = (RelativeLayout) findViewById(R.id.rl_userInfo);
        lv_left_menu = (ListView) findViewById(R.id.lv_left_menu);
        ib_writePost = (ImageButton) findViewById(R.id.ib_write_post);

    }

    private void setHead() {
        if (MyApplication.user != null) {
            loader.displayImage(MyApplication.user.getHeadURI(), ib_head, MyApplication.options);
            loader.displayImage(MyApplication.user.getHeadURI(), iv_headOnLeft, MyApplication.options);
            tv_userName.setText(MyApplication.user.getUserName());

        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_head:
                mMenu.changed();
                break;
            case R.id.tv_home:
                select(0);
                mMenu.closeMenu();
                break;
            case R.id.tv_heath_study:
                select(1);
                break;
            case R.id.tv_heath_trade:
                select(2);
                break;
            case R.id.tv_heath_chat:
                select(3);
                break;
            case R.id.right_content:
                //mMenu.closeMenu();
                //mMenu.changed();
                break;
            case R.id.rl_userInfo:
                Intent userCenter = new Intent(getApplicationContext(), ShowUserInfo.class);
                startActivityForResult(userCenter, 2);
                break;
            case R.id.ib_write_post:
                Intent writePost = new Intent(getApplicationContext(), WritePost.class);
                startActivity(writePost);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }

        if (resultCode == 2) {
            Bundle bundle = data.getExtras();
            int isChange = bundle.getInt("isChange");
            if (isChange == 1) {
                loader.clearMemoryCache();
                loader.clearDiskCache();
                if (MyApplication.headIsChange) {
                    loader.displayImage(MyApplication.user.getHeadURI(), ib_head, MyApplication.options);
                    loader.displayImage(MyApplication.user.getHeadURI(), iv_headOnLeft, MyApplication.options);
                    MyApplication.headIsChange = false;
                }
                if (MyApplication.userNameIsChange) {
                    tv_userName.setText(MyApplication.user.getUserName());
                    MyApplication.userNameIsChange = false;
                }
            }
        }
    }

    public void changeColor() {
        tv_home.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_study.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_chat.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_trade.setTextColor(getResources().getColor(R.color.gainsboro));

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onBackPressed() {
        if (mMenu.getMenuStatus()) {
            mMenu.closeMenu();
        } else {
            finish();
        }
    }


}
