package com.helper.ui;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.LeftMenuAdapter;
import com.helper.fragment.HeathChatFragment;
import com.helper.fragment.HeathStudyFragment;
import com.helper.fragment.HeathTradeFragment;
import com.helper.fragment.HomeFragment;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

/**
 * Created by 岑溪 on 2016/1/1.
 */
public class MainActivityUseDrawerLayout extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private ImageLoader loader = ImageLoader.getInstance();
    private ActionBarDrawerToggle mDrawerToggle;
    private ImageView iv_head;
    private LinearLayout ll_leftMenu;
    private DrawerLayout mDrawerLayout;
    private Toolbar mToolbar;
    private ImageButton ib_head;
    private TextView tv_userName;
    private Button homePage;
    private Button findPage;

    private TextView tv_home;
    private TextView tv_heath_study;
    private TextView tv_heath_trade;
    private TextView tv_heath_chat;

    private ImageButton ib_writePost;

    private RelativeLayout rl_userInfo;

    private HomeFragment homeFragment;
    private HeathStudyFragment heathStudyFragment;
    private HeathTradeFragment heathTradeFragment;
    private HeathChatFragment heathChatFragment;
    private ListView lv_left_menu;
    private String[] leftMenuTip;
    private ArrayList<String> list;
    private LeftMenuAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.main_use_drawerlayout);
        assignViews();
        setSupportActionBar(mToolbar);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, mToolbar, R.string.app_name, R.string.app_name);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        setUserNameAndHead();
        setLeftMenu();
        setListener();
        select(0);
    }

    private void assignViews() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.id_drawerLayout);
        mToolbar = (Toolbar) findViewById(R.id.id_toolbar);
        iv_head = (ImageView) findViewById(R.id.iv_head_left);
        tv_userName = (TextView) findViewById(R.id.tv_user_name);
        ll_leftMenu = (LinearLayout) findViewById(R.id.ll_left_menu);
        tv_home = (TextView) findViewById(R.id.tv_home);
        tv_heath_study = (TextView) findViewById(R.id.tv_heath_study);
        tv_heath_trade = (TextView) findViewById(R.id.tv_heath_trade);
        tv_heath_chat = (TextView) findViewById(R.id.tv_heath_chat);
        rl_userInfo = (RelativeLayout) findViewById(R.id.rl_userInfo);
        ib_writePost = (ImageButton) findViewById(R.id.ib_write_post);
        lv_left_menu = (ListView) findViewById(R.id.lv_left_menu);
    }

    private void setListener() {
        //ib_head.setOnClickListener(this);
        tv_home.setOnClickListener(this);
        tv_heath_study.setOnClickListener(this);
        tv_heath_trade.setOnClickListener(this);
        tv_heath_chat.setOnClickListener(this);
        // rightContent.setOnClickListener(this);
        rl_userInfo.setOnClickListener(this);
        lv_left_menu.setOnItemClickListener(this);
        ib_writePost.setOnClickListener(this);
    }

    private void setLeftMenu() {
        leftMenuTip = getResources().getStringArray(R.array.sa_left_menu_tip);
        list = new ArrayList<>();
        for (String s : leftMenuTip) {
            list.add(s);
        }
        adapter = new LeftMenuAdapter(list, getApplicationContext());
        lv_left_menu.setAdapter(adapter);

    }

    public void select(int i) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction(); //创建事务
        hideFragment(transaction);
        changeColor();
        switch (i) {
            case 0:
                if (homeFragment == null) {
                    homeFragment = new HomeFragment();
                    transaction.add(R.id.id_content, homeFragment);
                } else {
                    transaction.show(homeFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_home.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 1:
                if (heathStudyFragment == null) {
                    heathStudyFragment = new HeathStudyFragment();
                    transaction.add(R.id.id_content, heathStudyFragment);
                } else {
                    transaction.show(heathStudyFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_heath_study.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 2:
                if (heathTradeFragment == null) {
                    heathTradeFragment = new HeathTradeFragment();
                    transaction.add(R.id.id_content, heathTradeFragment);
                } else {
                    transaction.show(heathTradeFragment);
                }
                ib_writePost.setVisibility(View.GONE);
                tv_heath_trade.setTextColor(getResources().getColor(R.color.blue));
                break;
            case 3:
                if (heathChatFragment == null) {
                    heathChatFragment = new HeathChatFragment();
                    transaction.add(R.id.id_content, heathChatFragment);
                } else {
                    transaction.show(heathChatFragment);
                }
                ib_writePost.setVisibility(View.VISIBLE);
                tv_heath_chat.setTextColor(getResources().getColor(R.color.blue));
                break;
        }
        transaction.commit();
    }

    /**
     * 隐藏所有的Fragment
     *
     * @param transaction
     */
    private void hideFragment(FragmentTransaction transaction) {
        if (homeFragment != null) {
            transaction.hide(homeFragment);
        }
        if (heathStudyFragment != null) {
            transaction.hide(heathStudyFragment);
        }
        if (heathTradeFragment != null) {
            transaction.hide(heathTradeFragment);
        }
        if (heathChatFragment != null) {
            transaction.hide(heathChatFragment);
        }

    }


    private void setUserNameAndHead() {
        if (MyApplication.user != null) {
            loader.displayImage(MyApplication.user.getHeadURI(), iv_head, MyApplication.options);
            tv_userName.setText(MyApplication.user.getUserName());
        }

    }

    public void changeColor() {
        tv_home.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_study.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_chat.setTextColor(getResources().getColor(R.color.gainsboro));
        tv_heath_trade.setTextColor(getResources().getColor(R.color.gainsboro));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }

        if (resultCode == 2) {
            Bundle bundle = data.getExtras();
            int isChange = bundle.getInt("isChange");
            if (isChange == 1) {
                loader.clearMemoryCache();
                loader.clearDiskCache();
                if (MyApplication.headIsChange) {
                    loader.displayImage(MyApplication.user.getHeadURI(), iv_head, MyApplication.options);
                    MyApplication.headIsChange = false;
                }
                if (MyApplication.userNameIsChange) {
                    tv_userName.setText(MyApplication.user.getUserName());
                    MyApplication.userNameIsChange = false;
                }
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_head:
                break;
            case R.id.tv_home:
                select(0);
                break;
            case R.id.tv_heath_study:
                select(1);
                break;
            case R.id.tv_heath_trade:
                select(2);
                break;
            case R.id.tv_heath_chat:
                select(3);
                break;
            case R.id.rl_userInfo:
                Intent userCenter = new Intent(getApplicationContext(), ShowUserInfo.class);
                startActivityForResult(userCenter, 2);
                mDrawerLayout.closeDrawers();
                break;
            case R.id.ib_write_post:
                Intent writePost = new Intent(getApplicationContext(), WritePost.class);
                startActivity(writePost);
                break;
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = new MenuInflater(this);
        inflater.inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(Gravity.LEFT)) {
            mDrawerLayout.closeDrawers();
            return;
        }
        super.onBackPressed();
    }

}
