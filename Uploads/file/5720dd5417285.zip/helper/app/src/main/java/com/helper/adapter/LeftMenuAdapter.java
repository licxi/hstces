package com.helper.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.helper.R;

import java.util.ArrayList;

/**
 * Created by 岑溪 on 2015/8/18.
 */
public class LeftMenuAdapter extends BaseAdapter {

    public ArrayList<String> data;
    public Context context;
    private LayoutInflater inflater;
    public ViewHolder holder;

    public LeftMenuAdapter(ArrayList<String> data, Context context) {
        this.data = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_left_menu, null);
            holder.tip = (TextView) convertView.findViewById(R.id.tv_tip);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tip.setText(data.get(position).toString());
        return convertView;
    }

    public class ViewHolder {
        public TextView tip;

    }

    public void onDataChanged(ArrayList<String> data) {
        this.data = data;
        this.notifyDataSetChanged();
    }
}
