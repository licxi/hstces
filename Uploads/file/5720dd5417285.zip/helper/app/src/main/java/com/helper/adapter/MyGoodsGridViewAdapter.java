package com.helper.adapter;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.GoodsEntity;
import com.helper.utils.Tools;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 岑溪 on 2015/12/6.
 */
public class MyGoodsGridViewAdapter extends BaseAdapter {
    private ArrayList<GoodsEntity> datas;
    private ViewHolder holder;
    private LayoutInflater inflater;
    private ImageLoader loader = ImageLoader.getInstance();
    private Context context;

    public MyGoodsGridViewAdapter(ArrayList<GoodsEntity> datas, Context context) {
        this.datas = datas;
        this.inflater = LayoutInflater.from(context);
        this.context = context;
    }

    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_stageerd_goods, null);
            holder.iv_GoodsImg = (ImageView) convertView.findViewById(R.id.iv_goods_img);
            holder.tv_goodsName = (TextView) convertView.findViewById(R.id.tv_goods_name);
            holder.tv_goodsPrice = (TextView) convertView.findViewById(R.id.tv_goods_price);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        //holder.iv_typeImg.setImageResource(images[position]);
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        ViewGroup.LayoutParams lp = holder.iv_GoodsImg.getLayoutParams();
        lp.width = outMetrics.widthPixels / 2;
        holder.iv_GoodsImg.setLayoutParams(lp);
        loader.displayImage(datas.get(position).getGoodsImgURI(), holder.iv_GoodsImg, MyApplication.no_options);
        holder.tv_goodsName.setText(datas.get(position).getGoodsName());
        holder.tv_goodsPrice.setText("￥" + datas.get(position).getPrice());
        return convertView;
    }

    public class ViewHolder {
        public ImageView iv_GoodsImg;
        public TextView tv_goodsName;
        public TextView tv_goodsPrice;

    }
}
