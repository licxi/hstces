package com.helper.ui;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.PostInfoEntity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;


public class WritePost extends Activity implements OnClickListener {
    private ImageButton ib_close;
    private Button sendPost;
    private EditText et_postTitle;
    private EditText et_postBody;
    private String postTitle;
    private String postBody;
    private PostInfoEntity post;

    private AsyncHttpClient client;
    private RequestParams params;
    //private SubmitPost submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.write_post);
        init();
        setListener();
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
        sendPost.setOnClickListener(this);
    }

    private void init() {
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        sendPost = (Button) findViewById(R.id.send_post);
        et_postTitle = (EditText) findViewById(R.id.post_title);
        et_postBody = (EditText) findViewById(R.id.post_body);
    }

    @Override
    public void onClick(View button) {
        switch (button.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.send_post:
                post = new PostInfoEntity();
                postTitle = et_postTitle.getText().toString().trim();
                postBody = et_postBody.getText().toString().trim();
                if (postTitle.equals("")) {
                    Toast.makeText(this, "标题不能空!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (postBody.equals("")) {
                    Toast.makeText(this, "正文不能为空!", Toast.LENGTH_SHORT).show();
                    return;
                }
                post.setUserId(MyApplication.user.getUserPhone());
                post.setPostTitle(postTitle);
                post.setPostBody(postBody);
                post.setPostType(3);
                sendPost(post);
                break;
            default:
                break;
        }
    }

    private void sendPost(PostInfoEntity post) {
        String url = "http://" + MyApplication.IP + "/HeathHelper/AddPostServlet";
        client = new AsyncHttpClient();
        params = new RequestParams();
        params.add("userId", post.getUserId());
        params.add("postTitle", post.getPostTitle());
        params.add("postBody", post.getPostBody());
        params.add("postType", post.getPostType() + "");
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, byte[] bytes) {
                String status = new String(bytes);
                if (status.equals("1")) {
                    Toast.makeText(WritePost.this, "发送成功！", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(WritePost.this, "发送失败请重试！", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                Toast.makeText(WritePost.this, "发送失败！检查网络设置后重试！", Toast.LENGTH_SHORT).show();
            }
        });
    }


}
