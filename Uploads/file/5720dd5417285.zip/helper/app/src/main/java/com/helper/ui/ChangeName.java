package com.helper.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.db.UserDAO;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

/**
 * Created by 岑溪 on 2015/12/3.
 */
public class ChangeName extends Activity implements View.OnClickListener {
    String url = "http://" + MyApplication.IP + "/HeathHelper/UpdateUserNameServlet";
    private String updateName;
    private EditText et_ChangeName;
    private Button bt_saveChange;
    private ImageButton ib_close;
    private AsyncHttpClient client;
    private RequestParams params;
    private UserDAO userDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.change_name);
        assignViews();
        setListener();
    }

    private void assignViews() {
        et_ChangeName = (EditText) findViewById(R.id.et_user_name);
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        bt_saveChange = (Button) findViewById(R.id.bt_save_change);
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
        bt_saveChange.setOnClickListener(this);
        et_ChangeName.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.bt_save_change:
                updateName = et_ChangeName.getText().toString().trim();
                Toast.makeText(this, updateName, Toast.LENGTH_SHORT).show();
                if (updateName.equals(MyApplication.user.getUserName()))
                    finish();
                else if (updateName.equals("")) {
                    Toast.makeText(this, "用户名不能为空请重新输入！", Toast.LENGTH_SHORT).show();
                } else {
                    client = new AsyncHttpClient();
                    params = new RequestParams();
                    params.add("userPhone", MyApplication.user.getUserPhone());
                    params.add("updateUserName", updateName);
                    client.post(url, params, new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int i, Header[] headers, byte[] bytes) {
                            String result = new String(bytes);
                            if (result.equals("success")) {
                                Toast.makeText(ChangeName.this, "修改名字成功！", Toast.LENGTH_SHORT).show();
                                MyApplication.user.setUserName(updateName);
                                MyApplication.userNameIsChange = true;
                                userDAO = new UserDAO(getApplicationContext());
                                userDAO.setUserName(MyApplication.user.getUserPhone(), updateName);
                                Intent intent = new Intent();
                                intent.putExtra("isChange", 4);
                                setResult(4, intent);
                                finish();
                            } else {
                                Toast.makeText(ChangeName.this, "修改名字失败!", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                            Toast.makeText(ChangeName.this, "修改名字失败!,无网络连接", Toast.LENGTH_SHORT).show();
                        }
                    });

                }
                break;
        }
    }
}
