package com.helper.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDB extends SQLiteOpenHelper {
    String sql = "create table if not exists userdata (uPhone char(16) not null primary key,"
            + "uName varchar(50),"
            + "uHeadURI text,"
            + "isLogin int)";

    public UserDB(Context context, String name, CursorFactory factory,
                  int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {

    }

}
