package com.helper.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.utils.Tools;
import com.nostra13.universalimageloader.core.ImageLoader;

/**
 * Created by 岑溪 on 2015/12/3.
 */
public class ShowUserInfo extends Activity implements View.OnClickListener {
    private ImageLoader loader = ImageLoader.getInstance();
    private ImageButton ib_close;
    private ImageView iv_head;
    private TextView tv_userName;
    private RelativeLayout rl_updateHead;
    private RelativeLayout rl_updateUserName;
    private Uri tmpUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_show_user_info);
        assignViews();
        setListener();
        show();
    }

    private void show() {
        if (MyApplication.user != null) {
            loader.displayImage(MyApplication.user.headURI, iv_head, MyApplication.options);
            tv_userName.setText(MyApplication.user.getUserName());
        }
    }

    private void assignViews() {
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        iv_head = (ImageView) findViewById(R.id.iv_head_in_info);
        tv_userName = (TextView) findViewById(R.id.tv_user_name);
        rl_updateHead = (RelativeLayout) findViewById(R.id.rl_update_head);
        rl_updateUserName = (RelativeLayout) findViewById(R.id.rl_update_user_name);
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
        rl_updateUserName.setOnClickListener(this);
        rl_updateHead.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_close:
                Intent intent = new Intent();
                intent.putExtra("isChange", 1);
                setResult(2, intent);
                finish();
                break;
            case R.id.rl_update_head:
                if (Tools.checkConnected(getApplicationContext())) {
                    Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                    gallery.setType("image/*");  //获取图库
                    startActivityForResult(gallery, 2);
                }
                break;
            case R.id.rl_update_user_name:
                if (Tools.checkConnected(getApplicationContext())) {
                    Intent changeName = new Intent(getApplicationContext(), ChangeName.class);
                    startActivityForResult(changeName, 4);
                    break;
                }
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }
        if (requestCode == 1) {
           /* if(data == null){
                return;
            }else{
                Bundle bundle = data.getExtras();
                if(bundle!=null){
                    Bitmap bit = bundle.getParcelable("data");  //获取到摄像头拍摄的图片
                    Uri uri = Tools.saveBitmap(bit,"18098108580");  //获得bit的ur
                    imageZoom(uri);  //必须为 file的url
                }
            }*/
            return;
        }
        if (requestCode == 2) {
            if (data == null) {
                return;
            } else {

                //获取选中的图片的url
                Uri uri = data.getData();
                tmpUri = Tools.convertUri(uri, getContentResolver(), MyApplication.user.getUserPhone());
                imageZoom(tmpUri);
            }
        }
        if (requestCode == 3) {
            if (data == null)
                return;
            Bundle bundle = data.getExtras();
            Bitmap bit = bundle.getParcelable("data");
            //保存用户裁剪有的头像
            //loader.displayImage(Tools.saveBitmap(bit,MyApplication.user.getUserPhone()),ib_head,MyApplication.options);
            // 将图片保存到服务器
            if (Tools.sendImage(bit, getApplicationContext(), MyApplication.user.userPhone)) {
                Tools.saveBitmap(bit, MyApplication.user.getUserPhone());
                loader.clearMemoryCache();
                loader.clearDiskCache();
                loader.displayImage(MyApplication.user.getHeadURI(), iv_head, MyApplication.options);
            }

            // ib_head.setImageBitmap(bit);
            //Tools.sendImage(bit, getApplicationContext(), MyApplication.user.userPhone);// 将图片保存到服务器
        }

        if (requestCode == 4) {
            if (data == null)
                return;
            if (MyApplication.userNameIsChange) {
                tv_userName.setText(MyApplication.user.getUserName());
            }


        }
    }

    private void imageZoom(Uri uri) {
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.setDataAndType(uri, "image/*");
        intent.putExtra("crop", "true");
        intent.putExtra("aspectX", 1); //宽高的比例
        intent.putExtra("aspectY", 1);
        intent.putExtra("outputX", 150); //宽和高
        intent.putExtra("outputY", 150);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 3);
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("isChange", 1);
        setResult(2, intent);
        finish();
    }
}
