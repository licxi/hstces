package com.helper.entity;

public class GoodsEntity {
    private String goodsId;
    private String goodsName;
    private int goodsNumber;
    private String goodsImgURI;
    private double price;
    private String merchantId;

    public String getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(String goodsId) {
        this.goodsId = goodsId;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public int getGoodsNumber() {
        return goodsNumber;
    }

    public void setGoodsNumber(int goodsNumber) {
        this.goodsNumber = goodsNumber;
    }

    public String getGoodsImgURI() {
        return goodsImgURI;
    }

    public void setGoodsImgURI(String goodsImgURI) {
        this.goodsImgURI = goodsImgURI;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String toString() {
        StringBuffer goodsInfo;
        goodsInfo = new StringBuffer();
        goodsInfo.append("{");
        goodsInfo.append("goodsId:\"").append(goodsId).append("\",");
        goodsInfo.append("goodsName:\"").append(goodsName).append("\",");
        goodsInfo.append("goodsNumber:").append(goodsNumber).append("\",");
        goodsInfo.append("goodsImgURI:\"").append(goodsImgURI).append("\",");
        goodsInfo.append("price:").append(price).append("\",");
        goodsInfo.append("merchantId:\"").append(merchantId);
        goodsInfo.append("},");
        return goodsInfo.toString();
    }


}
