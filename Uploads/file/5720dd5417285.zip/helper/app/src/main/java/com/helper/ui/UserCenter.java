package com.helper.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.nostra13.universalimageloader.core.ImageLoader;

/**
 * Created by 岑溪 on 2015/12/3.
 */
public class UserCenter extends Activity implements View.OnClickListener {
    private RelativeLayout rl_userInfo;
    private ImageButton ib_close;
    private ImageView iv_head;
    private TextView tv_userName;
    private ImageLoader loader = ImageLoader.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_user_center);
        assignViews();
        show();
        setListener();
    }

    private void show() {
        if (MyApplication.user != null) {
            loader.displayImage(MyApplication.user.getHeadURI(), iv_head, MyApplication.options);
            tv_userName.setText(MyApplication.user.getUserName());
        }
    }

    private void assignViews() {
        rl_userInfo = (RelativeLayout) findViewById(R.id.rl_userInfo);
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        iv_head = (ImageView) findViewById(R.id.iv_head);
        tv_userName = (TextView) findViewById(R.id.tv_user_name);
    }

    private void setListener() {
        rl_userInfo.setOnClickListener(this);
        ib_close.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_close:
                Intent intent = new Intent();
                intent.putExtra("isChange", 1);
                setResult(1, intent);
                finish();
                break;
            case R.id.rl_userInfo:
                Intent showUserInfo = new Intent(getApplicationContext(), ShowUserInfo.class);
                startActivityForResult(showUserInfo, 2);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data == null) {
            return;
        }

        if (resultCode == 2) {
            Bundle bundle = data.getExtras();
            int isChange = bundle.getInt("isChange");
            Toast.makeText(this, "isChange:" + isChange, Toast.LENGTH_SHORT).show();
            if (isChange == 1) {
                loader.clearMemoryCache();
                loader.clearDiskCache();
                loader.displayImage(MyApplication.user.getHeadURI(), iv_head, MyApplication.options);
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        intent.putExtra("isChange", 1);
        setResult(2, intent);
        finish();
    }


}
