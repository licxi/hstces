package com.helper.adapter;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

/**
 * Created by 岑溪 on 2015/11/20.
 */
public class MyViewPagerAdapter extends PagerAdapter {
    //private List<View> mListView;
    private ImageView[] mListView;

    public MyViewPagerAdapter(ImageView[] mListView) {
        this.mListView = mListView;
    }

    @Override
    public int getCount() {
        return mListView.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    //实例化页面
    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        container.addView(mListView[position], 0); //添加页面
        return mListView[position];
    }

    //删除页面
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView(mListView[position]);
    }
}
