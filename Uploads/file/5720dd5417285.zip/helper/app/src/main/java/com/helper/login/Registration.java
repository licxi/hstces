package com.helper.login;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.db.UserDAO;
import com.helper.entity.UserEntity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class Registration extends Activity implements OnClickListener {
    private static final String url = "http://" + MyApplication.IP + "/HeathHelper/RegistrateServlet";
    private EditText et_user_phone;
    private EditText et_user_name;
    private EditText et_user_password;
    private EditText et_check_password;
    private Button bt_cancel;
    private Button bt_registration;
    private ImageButton ib_close;
    private String uPhone;
    private String uName;
    private String uPassword;
    private String checkPassword;
    private int state;
    private Dialog dialog;
    private UserDAO userDAO;
    private UserEntity user;
    private AsyncHttpClient client;
    private RequestParams params;
    private ProgressBar pb_re;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_registration);
        init();
        setListener();
    }

    private void init() {
        et_user_phone = (EditText) findViewById(R.id.et_user_phone);
        et_user_name = (EditText) findViewById(R.id.et_user_name);
        et_user_password = (EditText) findViewById(R.id.et_password);
        et_check_password = (EditText) findViewById(R.id.et_check_password);
        bt_registration = (Button) findViewById(R.id.bt_registration);
        bt_cancel = (Button) findViewById(R.id.bt_cancel_re);
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        pb_re = (ProgressBar) findViewById(R.id.pb_re);

    }

    private void setListener() {
        bt_cancel.setOnClickListener(this);
        bt_registration.setOnClickListener(this);
        ib_close.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.bt_cancel_re: {
                finish();
                break;
            }

            case R.id.bt_registration: {
                pb_re.setVisibility(View.VISIBLE);
                user = new UserEntity();
                uPhone = et_user_phone.getText().toString().trim();
                uName = et_user_name.getText().toString().trim();
                try {
                    uName = URLEncoder.encode(uName, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    System.out.print("转码错误::" + e.toString());
                }
                uPassword = et_user_password.getText().toString().trim();
                checkPassword = et_check_password.getText().toString().trim();
                if (uPhone.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "手机号不能空",
                            Toast.LENGTH_SHORT).show();

                } else if (uPassword.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "密码不能空",
                            Toast.LENGTH_SHORT).show();

                } else if (uName.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "用户名不能空",
                            Toast.LENGTH_SHORT).show();

                } else if (checkPassword.isEmpty()) {
                    Toast.makeText(this, "确认密码不能为空！", Toast.LENGTH_SHORT).show();

                } else if (!uPhone.isEmpty() && uPhone.length() != 11) {
                    Toast.makeText(this, "请输入正确的手机号", Toast.LENGTH_SHORT).show();

                } else if (uPassword.equals(checkPassword)) {
                    byte[] bytes;
                    String img = null;
                    ByteArrayOutputStream bis;
                    try { //添加默认的用户头像
                        bis = new ByteArrayOutputStream();
                        InputStream is = getAssets().open("ic_launcher.png");
                        BitmapFactory.decodeStream(is).compress(Bitmap.CompressFormat.PNG, 80, bis);
                        bytes = bis.toByteArray();
                        img = new String(Base64.encodeToString(bytes, Base64.DEFAULT));
                    } catch (IOException e) {
                        System.out.print("获取默认图片失败！" + e.toString());
                    }
                    client = new AsyncHttpClient();
                    params = new RequestParams();
                    params.add("userPhone", uPhone);
                    params.add("userName", uName);
                    params.add("password", uPassword);
                    params.add("head", img);
                    client.post(url, params, new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int i, Header[] headers, byte[] bytes) {
                            String resultInfo = new String(bytes);
                            switch (Integer.parseInt(resultInfo.substring(0, 1))) {
                                case 2:
                                    dialog = new AlertDialog.Builder(
                                            Registration.this)
                                            .setIcon(R.drawable.tishi)
                                            .setTitle("提示")
                                            .setMessage("注册失败，该账号已存在")
                                            .setPositiveButton("确认", null).create();
                                    dialog.show();
                                    pb_re.setVisibility(View.GONE);
                                    break;
                                case 0:
                                    dialog = new AlertDialog.Builder(
                                            Registration.this)
                                            .setIcon(R.drawable.tishi)
                                            .setTitle("提示").setMessage("注册失败,请重试")
                                            .setPositiveButton("确认", null).create();
                                    dialog.show();
                                    pb_re.setVisibility(View.GONE);
                                    break;
                                case 1:
                                    Toast.makeText(Registration.this, "注册成功,请使用注册的手机号登陆",
                                            Toast.LENGTH_LONG).show();
                                    pb_re.setVisibility(View.GONE);
                                    Intent intent = new Intent(getApplicationContext(), Login.class);
                                    startActivity(intent);
                                    finish();
                                    break;
                                default:
                                    break;

                            }

                        }

                        @Override
                        public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                            Toast.makeText(Registration.this, "注册失败，请检查网络设置，或重试", Toast.LENGTH_SHORT).show();
                            pb_re.setVisibility(View.GONE);
                        }
                    });
                    break;
                } else {
                    Toast.makeText(this, "两次密码输入不一致", Toast.LENGTH_SHORT).show();
                    pb_re.setVisibility(View.GONE);

                }
                pb_re.setVisibility(View.GONE);
            }
        }

    }
}
