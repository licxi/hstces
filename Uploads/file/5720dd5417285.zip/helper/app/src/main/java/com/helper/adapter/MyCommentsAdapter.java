package com.helper.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.CommentsEntity;
import com.helper.entity.PostInfoEntity;
import com.helper.utils.Tools;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

/**
 * Created by 岑溪 on 2016/1/7.
 */
public class MyCommentsAdapter extends BaseAdapter {
    private ArrayList<CommentsEntity> datas;
    private LayoutInflater inflater;
    private Context context;
    private ImageLoader loader = ImageLoader.getInstance();
    private ViewHolder holder;
    private CommentsEntity comments;


    public MyCommentsAdapter(ArrayList<CommentsEntity> datas, Context context) {
        this.datas = datas;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return datas.size();
    }


    @Override
    public Object getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_comments, null);
            holder.iv_commentsUserHead = (ImageView) convertView.findViewById(R.id.iv_comments_user_head);
            holder.tv_commentsUserName = (TextView) convertView.findViewById(R.id.tv_comments_userName);
            holder.tv_commentsSendTime = (TextView) convertView.findViewById(R.id.tv_comments_send_time);
            holder.tv_comments = (TextView) convertView.findViewById(R.id.tv_comments);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        comments = datas.get(position);
        if (comments.getUserHead().startsWith("file")) {
            loader.displayImage(comments.getUserHead(), holder.iv_commentsUserHead, MyApplication.options);
        } else {
            byte[] base = Base64.decode(comments.getUserHead(), Base64.DEFAULT);
            Bitmap bitmap = BitmapFactory.decodeByteArray(base, 0, base.length);
            String headUrl = Tools.saveBitmap(bitmap, comments.getUserPhone());
            loader.displayImage(headUrl, holder.iv_commentsUserHead, MyApplication.options);
        }
        holder.tv_commentsUserName.setText(comments.getUserName());
        holder.tv_commentsSendTime.setText(comments.getDate());
        holder.tv_comments.setText(comments.getComments());
        return convertView;
    }

    public class ViewHolder {
        public ImageView iv_commentsUserHead;
        public TextView tv_commentsUserName;
        public TextView tv_commentsSendTime;
        public TextView tv_comments;

    }

    public void onDataChanged(ArrayList<CommentsEntity> datas) {
        this.datas = datas;
        this.notifyDataSetChanged();
    }

}