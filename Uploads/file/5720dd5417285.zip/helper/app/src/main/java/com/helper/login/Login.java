package com.helper.login;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.helper.ui.MainActivity;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.db.UserDAO;
import com.helper.entity.LoginEntity;
import com.helper.ui.MainActivityUseDrawerLayout;
import com.helper.utils.Tools;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

import com.helper.entity.UserEntity;


/**
 * Created by 岑溪 on 2015/11/13.
 */
public class Login extends Activity implements View.OnClickListener {
    final static String url = "http://" + MyApplication.IP + "/HeathHelper/LoginServlet";
    private ImageButton ib_Close;
    private TextView tv_Title;
    private EditText et_UserPhone;
    private EditText et_Password;
    private Button bt_Login;
    private Button bt_Registration;
    private Button bt_Forgetpassword;
    private UserEntity user;
    private String uPhone;
    private String uPassword;
    private Dialog dialog;
    private UserDAO userDAO;
    private ProgressBar pb_login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_login);
        assignViews();
        setListener();

    }

    private void assignViews() {
        ib_Close = (ImageButton) findViewById(R.id.ib_close);
        tv_Title = (TextView) findViewById(R.id.tv_title);
        et_UserPhone = (EditText) findViewById(R.id.et_user_phone);
        et_Password = (EditText) findViewById(R.id.et_password);
        bt_Login = (Button) findViewById(R.id.bt_login);
        bt_Registration = (Button) findViewById(R.id.bt_registration);
        bt_Forgetpassword = (Button) findViewById(R.id.bt_forgetPassword);
        pb_login = (ProgressBar) findViewById(R.id.pb);
    }

    private void setListener() {
        et_UserPhone.setOnClickListener(this);
        et_Password.setOnClickListener(this);
        bt_Login.setOnClickListener(this);
        bt_Registration.setOnClickListener(this);
        ib_Close.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.bt_login: {
                pb_login.setVisibility(View.VISIBLE);
                user = new UserEntity();
                uPhone = et_UserPhone.getText().toString();
                uPassword = et_Password.getText().toString();
                if (uPhone.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "账号不能为空！",
                            Toast.LENGTH_SHORT).show();
                    pb_login.setVisibility(View.GONE);
                }
                if (uPassword.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "密码不能为空！",
                            Toast.LENGTH_SHORT).show();
                    pb_login.setVisibility(View.GONE);
                } else {
                    user.setUserPhone(uPhone);
                    AsyncHttpClient client = new AsyncHttpClient();
                    RequestParams params = new RequestParams();
                    params.add("userPhone", uPhone);
                    params.add("password", uPassword);
                    client.post(url, params, new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int i, Header[] headers, byte[] bytes) {
                            String result = new String(bytes);//中文是否会出现乱码
                            System.out.print("获取的内容：" + result);
                            if (result.startsWith("1")) {
                                Gson gson = new Gson();
                                LoginEntity loginInfo = gson.fromJson(result.substring(1), LoginEntity.class);
                                user.setUserPhone(loginInfo.getUserPhone());
                                user.setUserName(loginInfo.getUserName());
                                //将头像数据信息本地保存，并获取保存地址
                                System.out.print("head:" + loginInfo.getHead().toString());
                                System.out.print("phone:" + loginInfo.getUserPhone());
                                user.setHeadURI(Tools.getHeadURI(loginInfo.getHead().toString(), user.getUserPhone()));
                                userDAO = new UserDAO(getApplicationContext());
                                userDAO.insertUser(user);  //将用户信息保存到数据库
                                MyApplication.user = user;    //将用户信息保存application
                                Intent intent = new Intent(getApplicationContext(), MainActivityUseDrawerLayout.class);
                                startActivity(intent);
                                finish();
                            } else if (result.startsWith("0")) {
                                dialog = new AlertDialog.Builder(Login.this)
                                        .setIcon(R.drawable.tishi)
                                        .setTitle("提示").setMessage("登录失败,请重试")
                                        .setPositiveButton("确认", null).create();
                                dialog.show();
                                pb_login.setVisibility(View.GONE);
                            } else if (result.startsWith("-1")) {
                                dialog = new AlertDialog.Builder(Login.this)
                                        .setIcon(R.drawable.tishi)
                                        .setTitle("提示").setMessage("账号或密码错误，请重新输入，或找回密码")
                                        .setPositiveButton("确认", null).create();
                                dialog.show();
                                pb_login.setVisibility(View.GONE);
                            }
                            pb_login.setVisibility(View.GONE);
                        }

                        @Override
                        public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                            Toast.makeText(Login.this, "网络出现问题！", Toast.LENGTH_SHORT).show();
                            pb_login.setVisibility(View.GONE);
                        }
                    });
                }
                break;
            }
            case R.id.bt_registration: {
                Intent intent = new Intent(Login.this, Registration.class);
                startActivity(intent);
                break;
            }

        }

    }


/*    private Uri convertUri(Uri uri){
        InputStream is = null;
        try {
            is = getContentResolver().openInputStream(uri);
            Bitmap bit = BitmapFactory.decodeStream(is);  //将is装换成bitmap
            is.close();
            return saveBitmap(bit);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }*/


}

