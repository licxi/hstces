package com.helper.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.PostInfoEntity;
import com.helper.utils.Tools;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;

/**
 * Created by 岑溪 on 2015/12/13.
 */
public class MyChatListViewAdapter extends BaseAdapter {
    public ArrayList<PostInfoEntity> data;
    public Context context;
    private LayoutInflater inflater;
    public ViewHolder holder;
    private ImageLoader loader = ImageLoader.getInstance();

    public MyChatListViewAdapter(ArrayList<PostInfoEntity> data, Context context) {
        this.data = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_listview_chat_post, null);
            holder.tv_postTitle = (TextView) convertView.findViewById(R.id.tv_post_title);
            holder.iv_userHead = (ImageView) convertView.findViewById(R.id.iv_user_head);
            holder.tv_postSendTime = (TextView) convertView.findViewById(R.id.tv_post_send_time);
            holder.tv_postBody = (TextView) convertView.findViewById(R.id.tv_post_body);
            holder.iv_postImg = (ImageView) convertView.findViewById(R.id.iv_post_img);
            holder.tv_postLookNumber = (TextView) convertView.findViewById(R.id.tv_post_look_number);
            holder.tv_postLike = (TextView) convertView.findViewById(R.id.tv_post_like);
            holder.tv_postComments = (TextView) convertView.findViewById(R.id.tv_post_comments);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        byte[] base = Base64.decode(data.get(position).getUserHead(), Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(base, 0, base.length);
        String headUrl = Tools.saveBitmap(bitmap, data.get(position).getUserId());
        loader.displayImage(headUrl, holder.iv_userHead, MyApplication.options);
        holder.tv_postTitle.setText(data.get(position).getPostTitle());
        holder.tv_postSendTime.setText(data.get(position).getSendDate());
        holder.tv_postBody.setText(data.get(position).getPostBody());
        holder.tv_postLike.setText(data.get(position).getCountPraise() + "");
        return convertView;
    }

    public class ViewHolder {
        public TextView tv_postTitle;
        public ImageView iv_userHead;
        public TextView tv_postSendTime;
        public TextView tv_postBody;
        public ImageView iv_postImg;
        public TextView tv_postLookNumber;
        public TextView tv_postLike;
        public TextView tv_postComments;

    }

    public void onDataChanged(ArrayList<PostInfoEntity> data) {
        this.data = data;
        this.notifyDataSetChanged();
    }
}
