package com.helper.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.MyCommentsAdapter;
import com.helper.entity.CommentsEntity;
import com.helper.entity.PostInfoEntity;
import com.helper.utils.Tools;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.SyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;
import com.nostra13.universalimageloader.core.ImageLoader;

import org.apache.http.Header;

import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Created by 岑溪 on 2016/1/7.
 */
public class ViewPost extends Activity implements View.OnClickListener {
    private View postDetails;
    private ListView lv_viewPost;
    private TextView tv_postTitle;
    private TextView tv_postBody;
    private ImageView iv_postUserHead;
    private TextView tv_postUserName;
    private TextView tv_postSendTime;

    private ImageButton ib_close;
    private Button bt_writeComments;

    private String postId;
    private String postTitle;
    private String postBody;
    private String postUserName;
    private String postUserHead;
    private String date;
    private String postUserPhone;

    private MyCommentsAdapter adapter;
    private AsyncHttpClient client;
    private RequestParams params;
    private ArrayList<CommentsEntity> datas;
    private CommentsEntity comments;

    private ImageLoader loader = ImageLoader.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_view_post);
        assignView();
        init();
        show();
        setListener();

    }


    private void init() {
        Bundle bundle = getIntent().getExtras();
        postId = bundle.getString("postId");
        postTitle = bundle.getString("postTitle");
        postBody = bundle.getString("postBody");
        postUserPhone = bundle.getString("postUserPhone");
        postUserName = bundle.getString("postUserName");
        postUserHead = bundle.getString("postUserHead");
        date = bundle.getString("date");

        tv_postTitle.setText(postTitle);
        tv_postBody.setText(postBody);
        tv_postUserName.setText(postUserName);
        tv_postSendTime.setText(date);
        byte[] base = Base64.decode(postUserHead, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(base, 0, base.length);
        String headUrl = Tools.saveBitmap(bitmap, postUserPhone);
        loader.displayImage(headUrl, iv_postUserHead, MyApplication.options);

    }

    private void assignView() {
        postDetails = View.inflate(this, R.layout.post_details, null);
        lv_viewPost = (ListView) findViewById(R.id.lv_view_post);
        tv_postTitle = (TextView) postDetails.findViewById(R.id.tv_post_title);
        tv_postBody = (TextView) postDetails.findViewById(R.id.tv_post_body);
        tv_postUserName = (TextView) postDetails.findViewById(R.id.tv_post_user_name);
        tv_postSendTime = (TextView) postDetails.findViewById(R.id.tv_post_send_time);
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        iv_postUserHead = (ImageView) postDetails.findViewById(R.id.iv_post_user_head);
        bt_writeComments = (Button) findViewById(R.id.bt_write_comments);
        lv_viewPost.addHeaderView(postDetails);
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
        bt_writeComments.setOnClickListener(this);
    }

    public void show() {
        String url = "http://" + MyApplication.IP + "/HeathHelper/GetCommentsServlet";
        client = new AsyncHttpClient();
        params = new RequestParams();
        params.add("postId", postId);
        client.post(url, params, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int i, Header[] headers, String s, Throwable throwable) {
                Toast.makeText(ViewPost.this, "请求失败，请检查网络设置！", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onSuccess(int i, Header[] headers, String s) {
                Gson gson = new Gson();
                Type list = new TypeToken<ArrayList<CommentsEntity>>() {
                }.getType();
                datas = gson.fromJson(s, list);
                showDatas();

            }
        });

    }


    private void showDatas() {
        adapter = new MyCommentsAdapter(datas, this);
        lv_viewPost.setAdapter(adapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.bt_write_comments:
                Intent writeComments = new Intent(this, WriteComments.class);
                writeComments.putExtra("postId", postId);
                startActivityForResult(writeComments, 1);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (data != null) {
            if (requestCode == 1) {
                comments = new CommentsEntity();
                Bundle bundle = data.getExtras();
                comments.setComments(bundle.getString("comments"));
                comments.setDate(bundle.getString("date"));
                comments.setUserHead(MyApplication.user.getHeadURI());
                comments.setUserName(MyApplication.user.getUserName());
                Toast.makeText(this, comments.getComments(), Toast.LENGTH_SHORT).show();
                datas.add(lv_viewPost.getFirstVisiblePosition() + 1, comments);
                adapter.onDataChanged(datas);
            }
        }
    }
}
