package com.helper.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.ui.MainActivity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class Tools {
    /**
     * 是否有网络
     *
     * @param context
     * @return
     */
    public static boolean isNetwordConnected(Context context) {
        ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (networkInfo != null) {
            return networkInfo.isAvailable();
        }
        return false;
    }

    /**
     * 是否WIFI连接
     */
    public static boolean isWifiConnected(Context context) {
        ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager
                .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (networkInfo != null) {
            return networkInfo.isAvailable();
        }
        return false;
    }

    /**
     * 判断移动网路状态
     *
     * @param context
     * @return
     */
    public static boolean isMobliConnected(Context context) {
        ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager
                .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (networkInfo != null) {
            return networkInfo.isAvailable();
        }
        return false;
    }

    /**
     * 获取连接方式
     */

    public static int getConnectedType(Context context) {
        ConnectivityManager mConnectivityManager = (ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = mConnectivityManager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isAvailable())
            return networkInfo.getType();
        return -1;
    }

    /**
     * 从网络上获取图片
     *
     * @param path
     * @return
     */
    public static Drawable dowloadDrawable(final String path) {
        Drawable drawable = null;
        URL url;
        try {
            url = new URL(path);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() == 200) {
                drawable = Drawable.createFromStream(conn.getInputStream(),
                        "image");
            }
            return drawable;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean checkConnected(final Context context) {
        if (Tools.isNetwordConnected(context)) {
            //Toast.makeText(context, "������", Toast.LENGTH_LONG).show();
            return true;
        } else {
            Dialog dialog = new AlertDialog.Builder(context)
                    .setIcon(R.drawable.tishi)
                    .setTitle("提示")
                    .setMessage("无网络，请检查网络设置")
                    .setPositiveButton("确认",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(
                                        DialogInterface dialogInterface,
                                        int which) {
                                    context.startActivity(new Intent(
                                            Settings.ACTION_WIRELESS_SETTINGS));
                                }
                            }).create();
            dialog.show();
            return false;
        }
    }

    /**
     * 将图片的字符串信息在保存为图片，并返回本地的地址
     *
     * @param headString 图片的信息
     * @return 地址
     */
    public static String getHeadURI(String headString, String uPhone) {
        String uri;
        Bitmap bitmap;
        byte[] base = Base64.decode(headString, Base64.DEFAULT);
        bitmap = BitmapFactory.decodeByteArray(base, 0, base.length);
        uri = Tools.saveBitmap(bitmap, uPhone);
        return uri;
    }

    /**
     * 保存图片，返回图片的地址
     *
     * @param bm     bitmap格式 图片
     * @param uPhone 用户的手机号
     * @return
     */
    public static String saveBitmap(Bitmap bm, String uPhone) {
        //File dir = new File(Environment.getExternalStorageDirectory()+"/licxi/");
        File dir = new File("/sdcard/licxi/");
        if (!dir.exists()) {
            dir.mkdir();
        }
        File img = new File(dir.getAbsolutePath() + "/" + uPhone + ".png");
        //if(!img.exists()){
        try {
            try (FileOutputStream fos = new FileOutputStream(img)) {
                bm.compress(Bitmap.CompressFormat.PNG, 100, fos); //将bm写入fos输出流，用了保存图片
                fos.flush();
                fos.close();
            }
            return Uri.fromFile(img).toString();  //返回图片的file地址

        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        // }
        // return "file:///" + dir.getAbsolutePath() + "/" + uPhone + ".png";
    }

    public static String saveTempBitmap(Bitmap bm, String uPhone) {
        //File dir = new File(Environment.getExternalStorageDirectory()+"/licxi/");
        File dir = new File("/sdcard/licxi/temp");
        if (!dir.exists()) {
            dir.mkdir();
        }
        File img = new File(dir.getAbsolutePath() + "/" + uPhone + ".png");
        //if(!img.exists()){
        try {
            try (FileOutputStream fos = new FileOutputStream(img)) {
                bm.compress(Bitmap.CompressFormat.PNG, 100, fos); //将bm写入fos输出流，用了保存图片
                fos.flush();
                fos.close();
            }
            // return Uri.fromFile(img);  //返回图片的file地址
            return "file:///" + dir.getAbsolutePath() + "/" + uPhone + ".png";
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    } /*else {
            return "file:///"+dir.getAbsolutePath()+"/"+uPhone+".png";
		}
	}*/


    public static Uri convertUri(Uri uri, ContentResolver contentResolver, String userPhone) {
        InputStream is = null;
        try {
            is = contentResolver.openInputStream(uri);
            Bitmap bit = BitmapFactory.decodeStream(is);  //将is装换成bitmap
            is.close();
            return Uri.parse(saveTempBitmap(bit, userPhone));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 保存图像到服务器
     *
     * @param bm 要保存的图像
     */
    public static boolean sendImage(final Bitmap bm, final Context context, final String userPhone) {
        String url = "http://" + MyApplication.IP + "/HeathHelper/UpdateHeadServlet";
        ByteArrayOutputStream bis = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, bis);  //将图像转换为BYTE数组
        byte[] bytes = bis.toByteArray();
        String img = new String(Base64.encodeToString(bytes, Base64.DEFAULT));

        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();//上传的参数
        params.add("userPhone", userPhone);
        params.add("head", img);
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, byte[] bytes) {
                String resultInfo = new String(bytes);
                if (resultInfo.equals("true")) {
                    Toast.makeText(context, "上传成功", Toast.LENGTH_SHORT).show();
                    //saveBitmap(bm,userPhone);
                    MyApplication.headIsChange = true;
                } else {
                    Toast.makeText(context, "上传失败！", Toast.LENGTH_SHORT).show();
                    MyApplication.headIsChange = false;
                }

            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                Toast.makeText(context, "上传失败", Toast.LENGTH_SHORT).show();
                System.out.print("error" + throwable.getMessage());

            }
        });
        if (MyApplication.headIsChange) {
            return true;
        } else {
            return false;
        }

    }

    //获取屏幕宽度
    public static int getScreenWidthPixels(Activity context) {
        /*DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getRealMetrics(metric);*/
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.widthPixels;
    }

    //获取屏幕高度
    public static int getScreenHeightPixels(Activity context) {
        /*DisplayMetrics metric = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getRealMetrics(metric);*/

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        return outMetrics.heightPixels;
        //return metric.heightPixels;
    }
}
