package com.helper.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.MyGoodsGridViewAdapter;
import com.helper.entity.GoodsEntity;
import com.helper.entity.PostInfoEntity;
import com.helper.utils.Tools;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;

import org.apache.http.Header;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by 岑溪 on 2015/8/12.
 */
public class HeathTradeFragment extends Fragment {
    private static final String URL = "http://" + MyApplication.IP + "/HeathHelper/GetGoodsServlet";
    private GridView gv_goodsView;
    private MyGoodsGridViewAdapter myGoodsGridViewAdapter;
    private View view;
    private ArrayList<GoodsEntity> datas;
    private ProgressBar pb_loadingGoods;
    private AsyncHttpClient client;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_heath_trade, container, false);
        assignView();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        showGoods();

    }

    private void assignView() {
        // mRecyclerView = (RecyclerView) view.findViewById(R.id.rv_goods);
        gv_goodsView = (GridView) view.findViewById(R.id.gv_goods_view);
        pb_loadingGoods = (ProgressBar) view.findViewById(R.id.pb_loading_goods);
    }

    private void showGoods() {
        client = new AsyncHttpClient();
        client.post(URL, null, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, String response) {
                Gson gson = new Gson();
                Type list = new TypeToken<ArrayList<GoodsEntity>>() {
                }.getType();
                datas = gson.fromJson(response, list);
                pb_loadingGoods.setVisibility(View.GONE);
                show();
            }

            @Override
            public void onFailure(int i, Header[] headers, String response, Throwable throwable) {
                Toast.makeText(view.getContext(), "加载失败，请检查网络", Toast.LENGTH_SHORT).show();
            }


        });
    }

    private void show() {
        myGoodsGridViewAdapter = new MyGoodsGridViewAdapter(datas, view.getContext());
        gv_goodsView.setAdapter(myGoodsGridViewAdapter);
    }
}
