package com.helper;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

import com.helper.db.UserDAO;
import com.helper.entity.UserEntity;
import com.helper.login.Login;
import com.helper.ui.MainActivity;
import com.helper.ui.MainActivityUseDrawerLayout;
import com.helper.utils.Tools;


public class Loading extends Activity implements AnimationListener {
    private ImageView iv_loading_img;
    private UserDAO userDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);
        iv_loading_img = (ImageView) findViewById(R.id.iv_loading_img);
        AlphaAnimation img_animation = new AlphaAnimation(0.1f, 1.0f);
        img_animation.setDuration(2000);
        iv_loading_img.setAnimation(img_animation);
        img_animation.setAnimationListener(this);
    }

    //
    @Override
    public void onAnimationEnd(Animation arg0) {
        userDAO = new UserDAO(getApplicationContext());
        UserEntity user = userDAO.haveLogin();
        if (user != null) {
            MyApplication.user = user;
            Intent mainActivity = new Intent(Loading.this, MainActivityUseDrawerLayout.class);
            startActivity(mainActivity);
            finish();
        } else {
            /*Intent mainActivity = new Intent(Loading.this, FragmentPager.class);
            startActivity(mainActivity);
			finish();*/
            Intent mainActivity = new Intent(Loading.this, Login.class);
            startActivity(mainActivity);
            finish();
        }
    }

    @Override
    public void onAnimationRepeat(Animation arg0) {

    }

    @Override
    public void onAnimationStart(Animation arg0) {
        Tools.checkConnected(getApplicationContext());
    }

}
