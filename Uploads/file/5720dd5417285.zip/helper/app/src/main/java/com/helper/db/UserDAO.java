package com.helper.db;


import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.helper.entity.UserEntity;

import java.io.InputStream;
import java.util.Objects;


public class UserDAO {
    private Context context;
    private UserDB userDB;
    private UserEntity user = null;
    private SQLiteDatabase SQLiteDB;
    private Cursor cursor;
    final private String databaseName = "userDB.db";
    final private int version = 1;
    private InputStream is;
    StringBuffer sb;

    public UserDAO(Context context) {
        this.context = context;
        userDB = new UserDB(context, databaseName, null, version);
    }


    //查询是否有登录用户
    public UserEntity haveLogin() {
        String sql = "select * from userdata where isLogin=1";
        SQLiteDB = userDB.getReadableDatabase();
        cursor = SQLiteDB.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            user = new UserEntity();
            user.setUserPhone(cursor.getString(cursor.getColumnIndex("uPhone")));
            user.setUserName(cursor.getString(cursor.getColumnIndex("uName")));
            user.setHeadURI(cursor.getString(cursor.getColumnIndex("uHeadURI")));

        }
        return user;
    }

    //当用户登录时将用户信息记录下来，
    public void insertUser(UserEntity user) {
        String sql = "insert into userdata values(?,?,?,?)";
        if (!queryIsExist(user.getUserPhone())) {
            SQLiteDB = userDB.getWritableDatabase();
            SQLiteDB.execSQL(sql,
                    new Object[]{user.getUserPhone(), user.getUserName(), user.getHeadURI(), 1});
            userDB.close();
        }
    }

    //用户退出登录时
    public void userLogout(String uPhone) {
        String sql = "update userdata set isLogin=0 where uPhone=?";
        if (!queryIsExist(uPhone)) {
            SQLiteDB = userDB.getWritableDatabase();
            SQLiteDB.execSQL(sql, new Object[]{uPhone});
        }
    }


    public boolean queryIsExist(String uPhone) {
        String sql = "select * from userdata where uPhone=" + uPhone;
        SQLiteDB = userDB.getReadableDatabase();
        cursor = SQLiteDB.rawQuery(sql, null);
        user = new UserEntity();
        if (cursor.getCount() > 0) {
            return true;
        }
        return false;
    }

    public void setUserName(String userPhone, String updateName) {
        String sql = "update userdata set uName = ? where uPhone = ?";
        SQLiteDB = userDB.getWritableDatabase();
        if (queryIsExist(userPhone)) {
            SQLiteDB.execSQL(sql, new Object[]{updateName, userPhone});
        }
    }

    /**
     * ��ѯ�û�
     *
     * @param userId
     * @return Usermodel
     * @throws IOException
    public UserModel query(String userId) throws IOException {
    String sql = "select * from userdata where userId=" + userId;
    SQLiteDB = userDB.getReadableDatabase();
    cursor = SQLiteDB.rawQuery(sql, null);
    user = new UserModel();
    if (cursor.moveToNext()) {
    user.setUserId(cursor.getString(cursor.getColumnIndex("userId")));
    user.setUserPassword(cursor.getString(cursor.getColumnIndex("userPassword")));
    user.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
     *//*byte[] userHeadByte = cursor.getBlob(cursor.getColumnIndex("userHead"));
            ByteArrayInputStream is = new ByteArrayInputStream(userHeadByte);
			Drawable userHead = Drawable.createFromStream(is, "userHead");
			user.setUserHead(userHead);*//*
            byte[] userHeadByte = cursor.getBlob(cursor.getColumnIndex("userHead"));
			ByteArrayInputStream is = new ByteArrayInputStream(userHeadByte);
			if(is != null){
				int i = -1;
				byte[] b = new byte[128];
				sb = new StringBuffer();
				while((i = is.read(b))!=-1){
					sb.append(new String(b,0,i));
				}
				user.setUserHead(sb.toString());
			}
			user.setDescription(cursor.getString(cursor.getColumnIndex("description")));
		}
		userDB.close();
		return user;
	}

	public boolean queryIsExist(String userId) {
		String sql = "select * from userdata where userId=" + userId;
		SQLiteDB = userDB.getReadableDatabase();
		cursor = SQLiteDB.rawQuery(sql, null);
		user = new UserModel();
		if (cursor.getCount() > 0) {
			return true;
		}
		return false;
	}

	*//**
     * ����û�
     *
     * @param user
     *//*
	public void insertUser(UserModel user) {
		String sql = "insert into userdata values(?,?,?,?,?,?,?,?)";
		if (!queryIsExist(user.getUserId())) {
			SQLiteDB = userDB.getWritableDatabase();
			*//*ByteArrayOutputStream os = new ByteArrayOutputStream();
			BitmapDrawable head = (BitmapDrawable) user.getUserHead();
			head.getBitmap().compress(CompressFormat.PNG, 80, os);*//*
			SQLiteDB.execSQL(sql,
					new Object[] { user.getUserId(), user.getUserPassword(),
							user.getUserName(),user.getUserHead().getBytes(),user.getDescription() ,user.getUserAddress(),user.getUserPhone(),user.getUserSex()});
		}
		userDB.close();
	}

	*//**
     * ��ѯ�����û�
     * @return
     *//*
	public ArrayList<UserModel> queryAllUser() {
		ArrayList<UserModel> userList = new ArrayList<UserModel>();
		String sql = "select * from userdata";
		SQLiteDB = userDB.getReadableDatabase();
		cursor = SQLiteDB.rawQuery(sql, null);
		while(cursor.moveToNext()){
			*//*user = new UserModel();
			cursor.moveToNext();
			user.setUserId(cursor.getString(cursor.getColumnIndex("userId")));
			user.setUserPassword(cursor.getString(cursor.getColumnIndex("userPassword")));
			user.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
			byte[] headByte = cursor.getBlob(cursor.getColumnIndex("userHead"));
			ByteArrayInputStream is = new ByteArrayInputStream(headByte);
			Drawable userHead = Drawable.createFromStream(is, "head");
			user.setUserHead(userHead);
			user.setDescription(cursor.getString(cursor.getColumnIndex("description")));
			userList.add(user);*//*
			user = new UserModel();
			user.setUserId(cursor.getString(cursor.getColumnIndex("userId")));
			user.setUserPassword(cursor.getString(cursor.getColumnIndex("userPassword")));
			user.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
			byte[] headByte = cursor.getBlob(cursor.getColumnIndex("userHead"));
			*//*ByteArrayInputStream is = new ByteArrayInputStream(headByte);
			Drawable userHead = Drawable.createFromStream(is, "head");
			user.setUserHead(userHead);*//*
			user.setUserHead(headByte.toString());
			user.setDescription(cursor.getString(cursor.getColumnIndex("description")));
			user.setUserAddress(cursor.getString(cursor.getColumnIndex("userAddress")));
			user.setUserPhone(cursor.getString(cursor.getColumnIndex("userPhone")));
			user.setUserSex(cursor.getString(cursor.getColumnIndex("userSex")));
			userList.add(user);
		}
		return userList;
	}
	
	*//**
     * ��ѯ�׸��û�
     * @return
     *//*
	public UserModel queryUser() {
		String sql = "select * from userdata";
		SQLiteDB = userDB.getReadableDatabase();
		cursor = SQLiteDB.rawQuery(sql, null);
		if(cursor != null){
			user = new UserModel();
			cursor.moveToNext();
			user.setUserId(cursor.getString(cursor.getColumnIndex("userId")));
			user.setUserPassword(cursor.getString(cursor.getColumnIndex("userPassword")));
			user.setUserName(cursor.getString(cursor.getColumnIndex("userName")));
			byte[] headByte = cursor.getBlob(cursor.getColumnIndex("userHead"));
			*//*ByteArrayInputStream is = new ByteArrayInputStream(headByte);
			Drawable userHead = Drawable.createFromStream(is, "head");
			user.setUserHead(userHead);*//*
			user.setUserHead(headByte.toString());
			user.setDescription(cursor.getString(cursor.getColumnIndex("description")));
			user.setUserAddress(cursor.getString(cursor.getColumnIndex("userAddress")));
			user.setUserPhone(cursor.getString(cursor.getColumnIndex("userPhone")));
			user.setUserSex(cursor.getString(cursor.getColumnIndex("userSex")));
		}
		return user;
	}*/
}
