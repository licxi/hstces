package com.helper.entity;

/**
 * Created by 岑溪 on 2015/11/13.
 */
public class UserEntity {
    public String userPhone;
    public String userName;
    public String headURI;
    public int isLogin;

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHeadURI() {
        return headURI;
    }

    public void setHeadURI(String headURI) {
        this.headURI = headURI;
    }

    public int getIsLogin() {
        return isLogin;
    }

    public void setIsLogin(int isLogin) {
        this.isLogin = isLogin;
    }
}
