package com.helper.ui;

import android.app.Activity;
import android.app.DownloadManager;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.MyHomeListViewAdapter;
import com.helper.adapter.MyTypeListViewAdapter;
import com.helper.entity.PostInfoEntity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.apache.http.Header;

import java.util.ArrayList;

import in.srain.cube.views.ptr.PtrClassicFrameLayout;

/**
 * Created by 岑溪 on 2016/1/9.
 */
public class Type extends Activity implements View.OnClickListener {
    private Bundle bundle;
    private String type;
    private int typeId;

    private ListView lv_typePostList;
    private TextView tv_title;
    private ImageButton ib_close;
    private MyTypeListViewAdapter listViewAdapter;
    private ProgressBar progressBar;

    private AsyncHttpClient client;
    private RequestParams params;
    private ArrayList<PostInfoEntity> data;

    private PtrClassicFrameLayout mPtrFrameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.type);
        assignViews();
        bundle = getIntent().getExtras();
        typeId = bundle.getInt("typeId");
        type = bundle.getString("type");
        tv_title.setText(type);
        getData();
        setListener();
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
    }

    private void assignViews() {
        lv_typePostList = (ListView) findViewById(R.id.lv_type_post_list);
        tv_title = (TextView) findViewById(R.id.tv_title);
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        mPtrFrameLayout = (PtrClassicFrameLayout) findViewById(R.id.fl_classic_style);
        progressBar = (ProgressBar) findViewById(R.id.progressBarInType);
    }

    public void getData() {
        String url = "http://" + MyApplication.IP + "/HeathHelper/GetPostServlet";
        params = new RequestParams();
        params.add("type", typeId + "");
        client = new AsyncHttpClient();
        client.post(url, params, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Gson gson = new Gson();
                java.lang.reflect.Type list = new TypeToken<ArrayList<PostInfoEntity>>() {
                }.getType();
                data = gson.fromJson(response, list);
                progressBar.setVisibility(View.GONE);
                show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                Toast.makeText(getApplicationContext(), "加载失败！", Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void show() {
        if (listViewAdapter == null) {
            listViewAdapter = new MyTypeListViewAdapter(data, getApplicationContext());
            lv_typePostList.setAdapter(listViewAdapter);
        } else {
            // listViewAdapter.onDataChanged(data);
            lv_typePostList.setAdapter(listViewAdapter);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_close:
                finish();
        }
    }
}
