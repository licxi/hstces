package com.helper.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.PostInfoEntity;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

/**
 * Created by 岑溪 on 2015/12/4.
 */
public class MyHomeListViewAdapter extends BaseAdapter {
    private ArrayList<PostInfoEntity> data;
    private Context context;
    private LayoutInflater inflater;
    private ViewHolder holder;
    private ImageLoader loader = ImageLoader.getInstance();

    public MyHomeListViewAdapter(ArrayList<PostInfoEntity> data, Context context) {
        this.data = data;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_home_show, null);
            holder.tv_title = (TextView) convertView.findViewById(R.id.tv_title);
            holder.tv_time = (TextView) convertView.findViewById(R.id.tv_time);
            holder.tv_type = (TextView) convertView.findViewById(R.id.tv_type);
            holder.iv_img = (ImageView) convertView.findViewById(R.id.iv_img);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.tv_title.setText(data.get(position).getPostBody());
        holder.tv_time.setText(data.get(position).getSendDate());
        switch (data.get(position).getPostType()) {
            case 1:
                holder.tv_type.setText("美容");
                break;
            case 2:
                holder.tv_type.setText("妇女");
                break;
            case 4:
                holder.tv_type.setText("中医常识");
                break;
            default:
                holder.tv_type.setText("123");
                break;
        }
        if(!data.get(position).getImgURL().equals("null")){
            loader.displayImage(data.get(position).getImgURL(), holder.iv_img, MyApplication.no_options);
    }
        return convertView;
    }

    public class ViewHolder {
        public TextView tv_title;
        public TextView tv_time;
        public TextView tv_type;
        public ImageView iv_img;

    }

    public void onDataChanged(ArrayList<PostInfoEntity> data) {
        this.data = data;
        this.notifyDataSetChanged();
    }
}
