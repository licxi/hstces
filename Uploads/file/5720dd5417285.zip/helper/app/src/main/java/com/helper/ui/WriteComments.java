package com.helper.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.helper.MyApplication;
import com.helper.R;
import com.helper.entity.CommentsEntity;
import com.helper.entity.PostInfoEntity;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;

import java.text.SimpleDateFormat;
import java.util.Date;


public class WriteComments extends Activity implements OnClickListener {
    private ImageButton ib_close;
    private Button bt_sendComments;
    private EditText et_comments;
    private String comments;
    private CommentsEntity commentsEntity;
    private String postId;
    private Bundle bundle;
    private AsyncHttpClient client;
    private RequestParams params;
    //private SubmitPost submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.write_comments);
        bundle = getIntent().getExtras();
        postId = bundle.getString("postId");
        init();
        setListener();
    }

    private void setListener() {
        ib_close.setOnClickListener(this);
        bt_sendComments.setOnClickListener(this);
    }

    private void init() {
        ib_close = (ImageButton) findViewById(R.id.ib_close);
        bt_sendComments = (Button) findViewById(R.id.send_comments);
        et_comments = (EditText) findViewById(R.id.et_comments);
    }

    @Override
    public void onClick(View button) {
        switch (button.getId()) {
            case R.id.ib_close:
                finish();
                break;
            case R.id.send_comments:
                commentsEntity = new CommentsEntity();
                comments = et_comments.getText().toString().trim();
                if (comments.equals("")) {
                    Toast.makeText(this, "内容不能为空!", Toast.LENGTH_SHORT).show();
                    return;
                }
                commentsEntity.setComments(comments);
                commentsEntity.setUserPhone(MyApplication.user.getUserPhone());
                commentsEntity.setPostId(postId);
                sendComments(commentsEntity);
                break;
            default:
                break;
        }
    }

    private void sendComments(final CommentsEntity commentsEntity) {
        String url = "http://" + MyApplication.IP + "/HeathHelper/AddCommentsServlet";
        client = new AsyncHttpClient();
        params = new RequestParams();
        params.add("comments", commentsEntity.getComments());
        params.add("userPhone", commentsEntity.getUserPhone());
        params.add("postId", commentsEntity.getPostId());
        client.post(url, params, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int i, Header[] headers, byte[] bytes) {
                String status = new String(bytes);
                if (status.equals("1")) {
                    Toast.makeText(WriteComments.this, "发送成功！", Toast.LENGTH_SHORT).show();
                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Intent intent = new Intent();
                    intent.putExtra("comments", commentsEntity.getComments());
                    intent.putExtra("date", df.format(new Date()));
                    setResult(1, intent);
                    finish();
                } else {
                    Toast.makeText(WriteComments.this, "发送失败请重试！", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(int i, Header[] headers, byte[] bytes, Throwable throwable) {
                Toast.makeText(WriteComments.this, "发送失败！检查网络设置后重试！", Toast.LENGTH_SHORT).show();
            }
        });
    }


}
