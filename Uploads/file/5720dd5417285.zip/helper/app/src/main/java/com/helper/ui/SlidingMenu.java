package com.helper.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import com.nineoldandroids.view.ViewHelper;

/**
 * Created by 宀戞邯 on 2015/8/11.
 */
public class SlidingMenu extends HorizontalScrollView {
    private LinearLayout mWapper;
    private ViewGroup mMenu;
    private ViewGroup mContent;
    private ImageButton ib_head;

    private int mScreenWidth; //屏幕的宽度

    private int mMenuWidth;

    private int mMenuRightPadding = 80;
    private int padding = 80;

    private boolean once;
    private boolean isOpen = false;

    public SlidingMenu(Context context, AttributeSet attrs) {
        super(context, attrs);
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics outMetrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(outMetrics);
        mScreenWidth = outMetrics.widthPixels;
        //把dp转化为px
        mMenuRightPadding = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, padding,
                context.getResources().getDisplayMetrics());
    }


    public void changed() {
        if (isOpen) {
            this.smoothScrollTo(mMenuWidth, 0);
            ib_head.setAlpha(1.0f);
            isOpen = false;
        } else if (!isOpen) {
            this.smoothScrollTo(0, 0);
            ib_head.setAlpha(0.0f);
            isOpen = true;
        }
    }

    /**
     * @param widthMeasureSpec
     * @param heightMeasureSpec
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (!once) {
            mWapper = (LinearLayout) getChildAt(0);
            mMenu = (ViewGroup) mWapper.getChildAt(0);
            mContent = (ViewGroup) mWapper.getChildAt(1);
            mMenu.getLayoutParams().width = mScreenWidth - mMenuRightPadding;
            mMenuWidth = mScreenWidth - mMenuRightPadding;
            mContent.getLayoutParams().width = mScreenWidth;
            once = true;
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {

        super.onLayout(changed, l, t, r, b);
        if (changed) {
            this.scrollTo(mMenuWidth, 0);//
            ib_head.setAlpha(1.0f);
        }

    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getAction();
        switch (action) {
            case MotionEvent.ACTION_UP:  //
                int scrollX = getScrollX(); //还在隐藏的宽度
                if (scrollX >= mMenuWidth / 2) {
                    this.smoothScrollTo(mMenuWidth, 0);
                    ib_head.setAlpha(1.0f);
                    isOpen = false;
                } else {
                    this.smoothScrollTo(0, 0);
                    ib_head.setAlpha(0.0f);
                    isOpen = true;
                }
                return true;
        }

        return super.onTouchEvent(ev);
    }

    @Override
    protected void onScrollChanged(int l, int t, int oldl, int oldt) {

        super.onScrollChanged(l, t, oldl, oldt);
        float scale = l * 1.0f / mMenuWidth;
        float rightScale = 0.7f + 0.3f * scale;
        float leftScale = 1.0f - scale * 0.3f;
        float leftAlpha = 0.6f + 0.4f * (1 - scale);
        //mMenu.getChildAt(0).setTranslationX(mMenuWidth * scale * 0.7f);

        /*mMenu.setAlpha(leftAlpha);
        mMenu.getChildAt(0).setScaleX(leftScale);
        mMenu.getChildAt(0).setScaleY(leftScale);*//*
       mContent.setPivotX(0);  //设置缩放的中心点
        mContent.setPivotY(mContent.getHeight()/2);//设置缩放的中心点
        mContent.setScaleX(rightScale);
        mContent.setScaleY(rightScale);*/

        ViewHelper.setTranslationX(mMenu, mMenuWidth * scale * 0.7f);
        ViewHelper.setScaleX(mMenu.getChildAt(0), leftScale);
        ViewHelper.setScaleY(mMenu.getChildAt(0), leftScale);
        ViewHelper.setAlpha(mMenu, leftAlpha);
        // ViewHelper.setPivotX(mContent, 0);
        // ViewHelper.setPivotY(mContent, mContent.getHeight() / 2);
        //ViewHelper.setScaleX(mContent, rightScale);
        //ViewHelper.setScaleY(mContent,rightScale);
/*
        if (ib_head != null) {
            if (1.0 / (l - oldl) > 0.5f) {
                ib_head.setAlpha(1.0f);
            }

            AlphaAnimation animation = new AlphaAnimation(1.0f, 1.0f);
            ib_head.clearAnimation();
            animation.setDuration(1000);
            animation.setAnimationListener(this);

            //ib_head.setAnimation(animation);
            ib_head.startAnimation(animation);

        }*/


    }


    public void closeMenu() {
        if (isOpen) {
            this.smoothScrollTo(mMenuWidth, 0);
            ib_head.setAlpha(1.0f);
            isOpen = false;
        }
    }


    public Boolean getMenuStatus() {
        return isOpen;
    }

    public void setHeadAnimation(ImageButton ib_head) {
        this.ib_head = ib_head;
    }


}
