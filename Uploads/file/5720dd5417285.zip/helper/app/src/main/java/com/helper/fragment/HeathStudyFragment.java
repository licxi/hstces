package com.helper.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;

import com.helper.R;
import com.helper.adapter.MyHomeGridViewAdapter;
import com.helper.adapter.MyViewPagerAdapter;
import com.helper.ui.DisallowParentTouchViewPager;

/**
 * Created by 岑溪 on 2015/8/12.
 */
public class HeathStudyFragment extends Fragment {
    private View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_heath_study, container, false);
        return view;
    }
}
