package com.helper.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.helper.MyApplication;
import com.helper.R;
import com.helper.adapter.MyChatListViewAdapter;
import com.helper.entity.PostInfoEntity;
import com.helper.ui.ViewPost;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;
import com.loopj.android.http.TextHttpResponseHandler;

import org.apache.http.Header;

import java.lang.reflect.Type;
import java.util.ArrayList;

import in.srain.cube.views.ptr.PtrClassicFrameLayout;
import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;
import in.srain.cube.views.ptr.PtrHandler;

/**
 * Created by 岑溪 on 2015/12/4.
 */
public class HeathChatFragment extends Fragment implements AdapterView.OnItemClickListener {
    private View view;
    private ListView lv_postList;
    private MyChatListViewAdapter adapter;
    private PtrClassicFrameLayout mPtrFrameLayout;
    private ArrayList<PostInfoEntity> data = new ArrayList<>();
    private AsyncHttpClient client;
    private RequestParams params;
    private ProgressBar progressBar;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_heath_chat, container, false);
        assignViews();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getData();
        //show();
        //  mPtrFrameLayout.disableWhenHorizontalMove(true);
        //  mPtrFrameLayout.setHorizontalScrollBarEnabled(true);
        mPtrFrameLayout.setResistance(1.2f);
        mPtrFrameLayout.setPtrHandler(new PtrHandler() {
            @Override
            public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
                return PtrDefaultHandler.checkContentCanBePulledDown(frame, lv_postList, header);
                //return false;

            }

            @Override
            public void onRefreshBegin(final PtrFrameLayout frame) {
                // getMoreData();
                // show();
                frame.refreshComplete();
            }
        });
        lv_postList.setOnItemClickListener(this);
    }

    private void assignViews() {
        lv_postList = (ListView) view.findViewById(R.id.lv_post_list);
        mPtrFrameLayout = (PtrClassicFrameLayout) view.findViewById(R.id.fl_classic_style);
        progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
    }

    public void getData() {
        String url = "http://" + MyApplication.IP + "/HeathHelper/GetPostServlet";
        client = new AsyncHttpClient();
        params = new RequestParams();
        params.add("type", 3 + "");
        client.post(url, params, new TextHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, String response) {
                Gson gson = new Gson();
                Type list = new TypeToken<ArrayList<PostInfoEntity>>() {
                }.getType();
                data = gson.fromJson(response, list);
                progressBar.setVisibility(View.GONE);
                show();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseBody, Throwable error) {
                Toast.makeText(view.getContext(), "加载失败！", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void getMoreData() {
        for (int i = 0; i < 2; i++) {
            //data.add(0, "加载的数据");
        }
        // Toast.makeText(this, data.get(2).toString(), Toast.LENGTH_SHORT).show();
    }

    public void show() {
        if (adapter == null) {
            //lv_postList = (ListView) view.findViewById(R.id.lv_post_list);
            adapter = new MyChatListViewAdapter(data, view.getContext());
            lv_postList.setAdapter(adapter);
        } else {
            adapter.onDataChanged(data);
            //lv_postList.setAdapter(adapter);
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent viewPost = new Intent(view.getContext(), ViewPost.class);
        viewPost.putExtra("postId", data.get(position).getPostId());
        viewPost.putExtra("postTitle", data.get(position).getPostTitle());
        viewPost.putExtra("postBody", data.get(position).getPostBody());
        viewPost.putExtra("postUserPhone", data.get(position).getUserId());
        viewPost.putExtra("postUserName", data.get(position).getUserName());
        viewPost.putExtra("postUserHead", data.get(position).getUserHead());
        viewPost.putExtra("date", data.get(position).getSendDate());
        startActivity(viewPost);
    }
}
