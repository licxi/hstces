package com.helper.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.helper.R;

/**
 * Created by 岑溪 on 2015/12/6.
 */
public class MyHomeGridViewAdapter extends BaseAdapter {
    private int[] images;
    private ViewHolder holder;
    private LayoutInflater inflater;

    public MyHomeGridViewAdapter(int[] images, Context context) {
        this.images = images;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return images[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.item_home_gridview, null);
            holder.iv_typeImg = (ImageView) convertView.findViewById(R.id.iv_type_img);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.iv_typeImg.setImageResource(images[position]);
        return convertView;
    }

    public class ViewHolder {
        public ImageView iv_typeImg;

    }
}
